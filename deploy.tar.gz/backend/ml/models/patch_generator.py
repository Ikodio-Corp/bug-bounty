"""
Patch Generator ML Model - 90-Second Promise Implementation

This module implements AI-powered automatic patch generation for discovered vulnerabilities.
Generates secure code fixes with validation, rollback mechanisms, and multi-framework support.
"""

import asyncio
import difflib
import hashlib
import json
import logging
import re
import time
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class PatchLanguage(str, Enum):
    """Supported languages for patch generation."""
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    JAVA = "java"
    GO = "go"
    PHP = "php"
    RUBY = "ruby"
    CSHARP = "csharp"


class Framework(str, Enum):
    """Supported frameworks."""
    DJANGO = "django"
    FLASK = "flask"
    FASTAPI = "fastapi"
    EXPRESS = "express"
    NESTJS = "nestjs"
    SPRING_BOOT = "spring_boot"
    RAILS = "rails"
    LARAVEL = "laravel"
    GIN = "gin"
    ASPNET = "aspnet"


class PatchType(str, Enum):
    """Types of patches."""
    CODE_FIX = "code_fix"
    CONFIG_CHANGE = "config_change"
    DEPENDENCY_UPDATE = "dependency_update"
    SECURITY_HEADER = "security_header"
    INPUT_VALIDATION = "input_validation"
    ACCESS_CONTROL = "access_control"


class PatchStatus(str, Enum):
    """Patch status."""
    GENERATED = "generated"
    VALIDATED = "validated"
    APPLIED = "applied"
    ROLLED_BACK = "rolled_back"
    FAILED = "failed"


class CodeDiff(BaseModel):
    """Model for code diff."""
    file_path: str
    original_code: str
    patched_code: str
    diff_text: str
    line_changes: int
    additions: int
    deletions: int


class GeneratedPatch(BaseModel):
    """Model for generated patch."""
    patch_id: str
    vulnerability_id: str
    vulnerability_type: str
    patch_type: PatchType
    language: PatchLanguage
    framework: Optional[Framework] = None
    title: str
    description: str
    diffs: List[CodeDiff]
    validation_tests: List[str] = []
    rollback_instructions: str = ""
    breaking_changes: List[str] = []
    dependencies: List[str] = []
    configuration_changes: List[Dict[str, Any]] = []
    status: PatchStatus = PatchStatus.GENERATED
    confidence: float = Field(ge=0.0, le=1.0, default=0.8)
    generated_at: datetime = Field(default_factory=datetime.utcnow)
    generation_time_ms: int = 0
    applied_at: Optional[datetime] = None
    applied_by: Optional[str] = None


class PatchTemplate(BaseModel):
    """Template for patch generation."""
    template_id: str
    vulnerability_type: str
    language: PatchLanguage
    framework: Optional[Framework] = None
    pattern_to_find: str
    replacement_pattern: str
    description: str
    validation_test: str
    imports_required: List[str] = []
    confidence_base: float = 0.85


class PatchGeneratorConfig(BaseModel):
    """Configuration for patch generator."""
    timeout_seconds: int = 90
    enable_ai_generation: bool = True
    enable_template_generation: bool = True
    include_validation_tests: bool = True
    include_rollback: bool = True
    max_diff_lines: int = 500
    confidence_threshold: float = 0.7


class PatchGeneratorModel:
    """
    AI-powered Patch Generator implementing the 90-second promise.

    This model generates:
    1. Secure code fixes for vulnerabilities
    2. Input validation code
    3. Configuration changes
    4. Dependency updates

    Features:
    - Multi-language support
    - Framework-specific patches
    - Validation test generation
    - Rollback mechanisms
    """

    def __init__(self, config: Optional[PatchGeneratorConfig] = None):
        """Initialize the patch generator."""
        self.config = config or PatchGeneratorConfig()
        self._templates: Dict[str, List[PatchTemplate]] = {}
        self._load_templates()
        logger.info("PatchGeneratorModel initialized")

    def _load_templates(self) -> None:
        """Load patch templates for various vulnerability types."""

        # SQL Injection patches
        self._templates["sql_injection"] = [
            PatchTemplate(
                template_id="sqli-python-parameterized",
                vulnerability_type="sql_injection",
                language=PatchLanguage.PYTHON,
                pattern_to_find=r'cursor\.execute\s*\(\s*["\'].*?%s.*?["\']\s*%\s*\(?([^)]+)\)?\s*\)',
                replacement_pattern='cursor.execute("SELECT * FROM users WHERE id = %s", ({param},))',
                description="Convert string formatting to parameterized query",
                validation_test='''
def test_sql_injection_fixed():
    """Test that SQL injection is properly prevented."""
    malicious_input = "'; DROP TABLE users; --"
    # Should not execute malicious SQL
    result = execute_query(malicious_input)
    assert "DROP TABLE" not in str(result)
''',
                imports_required=[]
            ),
            PatchTemplate(
                template_id="sqli-python-orm",
                vulnerability_type="sql_injection",
                language=PatchLanguage.PYTHON,
                framework=Framework.DJANGO,
                pattern_to_find=r'\.raw\s*\(\s*f["\'].*?\{.*?\}.*?["\']\s*\)',
                replacement_pattern='.filter(**{field: value})',
                description="Replace raw SQL with ORM query",
                validation_test='''
def test_django_orm_query():
    """Test that ORM query is used instead of raw SQL."""
    from django.db import connection
    # Verify parameterized query is used
    result = Model.objects.filter(field=user_input)
    assert result.query.sql_with_params()[1]  # Has parameters
''',
                imports_required=[]
            ),
            PatchTemplate(
                template_id="sqli-js-prepared",
                vulnerability_type="sql_injection",
                language=PatchLanguage.JAVASCRIPT,
                pattern_to_find=r'query\s*\(\s*`.*?\$\{.*?\}.*?`\s*\)',
                replacement_pattern='query("SELECT * FROM users WHERE id = $1", [param])',
                description="Convert template literal to prepared statement",
                validation_test='''
describe("SQL Injection Prevention", () => {
    it("should use prepared statements", async () => {
        const malicious = "'; DROP TABLE users; --";
        const result = await db.query(
            "SELECT * FROM users WHERE id = $1",
            [malicious]
        );
        // Should escape the input
        expect(result.rows).toBeDefined();
    });
});
''',
                imports_required=[]
            ),
        ]

        # XSS patches
        self._templates["xss"] = [
            PatchTemplate(
                template_id="xss-js-sanitize",
                vulnerability_type="xss",
                language=PatchLanguage.JAVASCRIPT,
                pattern_to_find=r'\.innerHTML\s*=\s*([^;]+)',
                replacement_pattern='.textContent = {param}',
                description="Replace innerHTML with textContent",
                validation_test='''
describe("XSS Prevention", () => {
    it("should escape HTML in textContent", () => {
        const malicious = "<script>alert('xss')</script>";
        element.textContent = malicious;
        expect(element.innerHTML).not.toContain("<script>");
    });
});
''',
                imports_required=[]
            ),
            PatchTemplate(
                template_id="xss-react-sanitize",
                vulnerability_type="xss",
                language=PatchLanguage.TYPESCRIPT,
                framework=Framework.NESTJS,
                pattern_to_find=r'dangerouslySetInnerHTML\s*=\s*\{\s*__html\s*:\s*([^}]+)\s*\}',
                replacement_pattern='dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize({param}) }}',
                description="Sanitize HTML before rendering with DOMPurify",
                validation_test='''
describe("React XSS Prevention", () => {
    it("should sanitize HTML content", () => {
        const dirty = "<img src=x onerror=alert('xss')>";
        const clean = DOMPurify.sanitize(dirty);
        expect(clean).not.toContain("onerror");
    });
});
''',
                imports_required=["import DOMPurify from 'dompurify';"]
            ),
            PatchTemplate(
                template_id="xss-python-escape",
                vulnerability_type="xss",
                language=PatchLanguage.PYTHON,
                framework=Framework.FLASK,
                pattern_to_find=r'return\s+render_template_string\s*\(\s*f["\'].*?\{.*?\}.*?["\']\s*\)',
                replacement_pattern='return render_template_string(template, **{variable: escape(value)})',
                description="Escape user input in Flask templates",
                validation_test='''
def test_xss_escaped():
    """Test that XSS is properly escaped."""
    from markupsafe import escape
    malicious = "<script>alert('xss')</script>"
    escaped = escape(malicious)
    assert "<script>" not in str(escaped)
    assert "&lt;script&gt;" in str(escaped)
''',
                imports_required=["from markupsafe import escape"]
            ),
        ]

        # Command Injection patches
        self._templates["command_injection"] = [
            PatchTemplate(
                template_id="cmdi-python-subprocess",
                vulnerability_type="command_injection",
                language=PatchLanguage.PYTHON,
                pattern_to_find=r'os\.system\s*\(\s*(?:f["\']|["\'].*?%|.*?\+).*?\)',
                replacement_pattern='subprocess.run([command, arg1, arg2], shell=False, check=True)',
                description="Replace os.system with subprocess and shell=False",
                validation_test='''
def test_command_injection_prevented():
    """Test that command injection is prevented."""
    import subprocess
    malicious = "; rm -rf /"
    # Should treat as literal argument
    result = subprocess.run(
        ["echo", malicious],
        shell=False,
        capture_output=True
    )
    assert "; rm" in result.stdout.decode()  # Treated as text
''',
                imports_required=["import subprocess"]
            ),
            PatchTemplate(
                template_id="cmdi-python-shlex",
                vulnerability_type="command_injection",
                language=PatchLanguage.PYTHON,
                pattern_to_find=r'subprocess\.(?:call|run|Popen)\s*\([^)]*shell\s*=\s*True[^)]*\)',
                replacement_pattern='subprocess.run(shlex.split(command), shell=False)',
                description="Use shlex.split for safe command parsing",
                validation_test='''
def test_shlex_parsing():
    """Test that shlex properly parses commands."""
    import shlex
    command = "echo 'hello world'"
    args = shlex.split(command)
    assert args == ["echo", "hello world"]
''',
                imports_required=["import shlex", "import subprocess"]
            ),
            PatchTemplate(
                template_id="cmdi-js-execfile",
                vulnerability_type="command_injection",
                language=PatchLanguage.JAVASCRIPT,
                pattern_to_find=r'exec\s*\(\s*(?:`.*?\$\{|.*?\+).*?\)',
                replacement_pattern='execFile(command, args, callback)',
                description="Replace exec with execFile and argument array",
                validation_test='''
describe("Command Injection Prevention", () => {
    it("should use execFile with array args", (done) => {
        const { execFile } = require("child_process");
        const malicious = "; rm -rf /";
        execFile("echo", [malicious], (error, stdout) => {
            expect(stdout).toContain("; rm -rf /");
            done();
        });
    });
});
''',
                imports_required=["const { execFile } = require('child_process');"]
            ),
        ]

        # Path Traversal patches
        self._templates["path_traversal"] = [
            PatchTemplate(
                template_id="path-python-secure",
                vulnerability_type="path_traversal",
                language=PatchLanguage.PYTHON,
                pattern_to_find=r'open\s*\(\s*(?:f["\']|.*?\+|.*?%|.*?\.format).*?\)',
                replacement_pattern='open(secure_path(base_dir, user_input))',
                description="Validate and sanitize file paths",
                validation_test='''
def test_path_traversal_prevented():
    """Test that path traversal is prevented."""
    import os

    def secure_path(base, user_input):
        # Resolve to absolute path
        requested = os.path.abspath(os.path.join(base, user_input))
        base_abs = os.path.abspath(base)
        # Ensure path is within base
        if not requested.startswith(base_abs):
            raise ValueError("Path traversal detected")
        return requested

    base = "/app/uploads"
    try:
        secure_path(base, "../../../etc/passwd")
        assert False, "Should have raised error"
    except ValueError:
        pass  # Expected
''',
                imports_required=["import os"]
            ),
            PatchTemplate(
                template_id="path-js-secure",
                vulnerability_type="path_traversal",
                language=PatchLanguage.JAVASCRIPT,
                pattern_to_find=r'(?:readFile|writeFile)\s*\(\s*(?:`.*?\$\{|.*?\+).*?\)',
                replacement_pattern='readFile(securePath(baseDir, userInput))',
                description="Validate file paths against base directory",
                validation_test='''
describe("Path Traversal Prevention", () => {
    it("should prevent directory escape", () => {
        const path = require("path");

        function securePath(base, userInput) {
            const requested = path.resolve(base, userInput);
            const baseAbs = path.resolve(base);
            if (!requested.startsWith(baseAbs)) {
                throw new Error("Path traversal detected");
            }
            return requested;
        }

        expect(() => {
            securePath("/app/uploads", "../../../etc/passwd");
        }).toThrow("Path traversal detected");
    });
});
''',
                imports_required=["const path = require('path');"]
            ),
        ]

        # SSRF patches
        self._templates["ssrf"] = [
            PatchTemplate(
                template_id="ssrf-python-validate",
                vulnerability_type="ssrf",
                language=PatchLanguage.PYTHON,
                pattern_to_find=r'requests\.(?:get|post)\s*\(\s*(?:f["\']|.*?\+|.*?%|.*?\.format).*?\)',
                replacement_pattern='requests.get(validate_url(user_url))',
                description="Validate URLs against allowlist and block internal IPs",
                validation_test='''
def test_ssrf_prevented():
    """Test that SSRF is prevented."""
    import ipaddress
    from urllib.parse import urlparse

    def validate_url(url):
        parsed = urlparse(url)

        # Check scheme
        if parsed.scheme not in ("http", "https"):
            raise ValueError("Invalid scheme")

        # Check for internal IPs
        try:
            ip = ipaddress.ip_address(parsed.hostname)
            if ip.is_private or ip.is_loopback or ip.is_reserved:
                raise ValueError("Internal IP not allowed")
        except ValueError as e:
            if "Internal IP" in str(e):
                raise
            # Hostname, not IP - continue with DNS check
            pass

        return url

    # Test internal IP blocking
    try:
        validate_url("http://127.0.0.1/")
        assert False, "Should block localhost"
    except ValueError:
        pass

    try:
        validate_url("http://169.254.169.254/")
        assert False, "Should block metadata IP"
    except ValueError:
        pass
''',
                imports_required=["import ipaddress", "from urllib.parse import urlparse"]
            ),
        ]

        # Hardcoded Secrets patches
        self._templates["hardcoded_secrets"] = [
            PatchTemplate(
                template_id="secret-python-env",
                vulnerability_type="hardcoded_secrets",
                language=PatchLanguage.PYTHON,
                pattern_to_find=r'(?:api_key|secret|password)\s*=\s*["\'][^"\']{8,}["\']',
                replacement_pattern='{variable} = os.environ.get("{ENV_VAR}")',
                description="Move secrets to environment variables",
                validation_test='''
def test_secrets_from_env():
    """Test that secrets are loaded from environment."""
    import os

    # Should not be hardcoded
    api_key = os.environ.get("API_KEY")
    assert api_key is not None, "API_KEY env var not set"

    # Verify not in source code
    with open(__file__) as f:
        source = f.read()
        assert "hardcoded_api_key_value" not in source
''',
                imports_required=["import os"]
            ),
            PatchTemplate(
                template_id="secret-js-env",
                vulnerability_type="hardcoded_secrets",
                language=PatchLanguage.JAVASCRIPT,
                pattern_to_find=r'(?:apiKey|secret|password)\s*[:=]\s*["\'][^"\']{8,}["\']',
                replacement_pattern='{variable}: process.env.{ENV_VAR}',
                description="Load secrets from environment variables",
                validation_test='''
describe("Secret Management", () => {
    it("should load secrets from environment", () => {
        const apiKey = process.env.API_KEY;
        expect(apiKey).toBeDefined();
        expect(typeof apiKey).toBe("string");
    });
});
''',
                imports_required=["require('dotenv').config();"]
            ),
        ]

        # Crypto Weakness patches
        self._templates["crypto_weakness"] = [
            PatchTemplate(
                template_id="crypto-python-sha256",
                vulnerability_type="crypto_weakness",
                language=PatchLanguage.PYTHON,
                pattern_to_find=r'hashlib\.(?:md5|sha1)\s*\(',
                replacement_pattern='hashlib.sha256(',
                description="Upgrade to SHA-256 hash algorithm",
                validation_test='''
def test_strong_hash():
    """Test that strong hash algorithm is used."""
    import hashlib

    data = b"test data"
    hash_result = hashlib.sha256(data).hexdigest()

    # SHA-256 produces 64 character hex string
    assert len(hash_result) == 64
''',
                imports_required=["import hashlib"]
            ),
        ]

        logger.info(f"Loaded patch templates for {len(self._templates)} vulnerability types")

    def _generate_patch_id(self, vuln_id: str, vuln_type: str) -> str:
        """Generate unique patch ID."""
        content = f"{vuln_id}:{vuln_type}:{time.time()}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def _generate_diff(
        self,
        file_path: str,
        original_code: str,
        patched_code: str
    ) -> CodeDiff:
        """Generate unified diff between original and patched code."""
        original_lines = original_code.splitlines(keepends=True)
        patched_lines = patched_code.splitlines(keepends=True)

        diff = difflib.unified_diff(
            original_lines,
            patched_lines,
            fromfile=f"a/{file_path}",
            tofile=f"b/{file_path}",
            lineterm=""
        )

        diff_text = "".join(diff)

        # Calculate statistics
        additions = sum(1 for line in patched_lines if line not in original_lines)
        deletions = sum(1 for line in original_lines if line not in patched_lines)
        line_changes = additions + deletions

        return CodeDiff(
            file_path=file_path,
            original_code=original_code,
            patched_code=patched_code,
            diff_text=diff_text,
            line_changes=line_changes,
            additions=additions,
            deletions=deletions
        )

    def _apply_template_patch(
        self,
        template: PatchTemplate,
        original_code: str,
        context: Dict[str, str]
    ) -> Tuple[str, bool]:
        """Apply template-based patch to code."""
        try:
            # Find pattern in code
            pattern = re.compile(template.pattern_to_find)
            match = pattern.search(original_code)

            if not match:
                return original_code, False

            # Build replacement
            replacement = template.replacement_pattern
            for key, value in context.items():
                replacement = replacement.replace("{" + key + "}", value)

            # Apply replacement
            patched_code = pattern.sub(replacement, original_code)

            # Add required imports
            if template.imports_required:
                import_block = "\n".join(template.imports_required)
                if import_block not in patched_code:
                    # Find existing import section or add at top
                    if "import " in patched_code:
                        # Add after last import
                        lines = patched_code.split("\n")
                        last_import_idx = 0
                        for i, line in enumerate(lines):
                            if line.strip().startswith(("import ", "from ")):
                                last_import_idx = i

                        lines.insert(last_import_idx + 1, import_block)
                        patched_code = "\n".join(lines)
                    else:
                        patched_code = import_block + "\n\n" + patched_code

            return patched_code, True

        except Exception as e:
            logger.error(f"Failed to apply template patch: {e}")
            return original_code, False

    async def generate(
        self,
        vulnerability_id: str,
        vulnerability_type: str,
        original_code: str,
        file_path: str,
        language: PatchLanguage,
        framework: Optional[Framework] = None,
        context: Optional[Dict[str, str]] = None
    ) -> GeneratedPatch:
        """
        Generate a patch for a vulnerability.

        Args:
            vulnerability_id: ID of the vulnerability
            vulnerability_type: Type of vulnerability
            original_code: Original vulnerable code
            file_path: Path to the file
            language: Programming language
            framework: Optional framework
            context: Additional context for patch generation

        Returns:
            Generated patch with diff and validation tests
        """
        start_time = time.time()
        context = context or {}

        # Find matching templates
        templates = self._templates.get(vulnerability_type, [])
        matching_templates = []

        for template in templates:
            if template.language == language:
                if framework and template.framework == framework:
                    matching_templates.insert(0, template)  # Prioritize framework-specific
                elif not template.framework:
                    matching_templates.append(template)

        if not matching_templates and templates:
            # Use any template for this vulnerability type
            matching_templates = [t for t in templates if t.language == language]

        if not matching_templates:
            raise ValueError(f"No patch template for {vulnerability_type} in {language.value}")

        # Try each template until one succeeds
        patched_code = original_code
        applied_template = None
        validation_tests = []

        for template in matching_templates:
            patched_code, success = self._apply_template_patch(
                template,
                original_code,
                context
            )
            if success:
                applied_template = template
                if template.validation_test:
                    validation_tests.append(template.validation_test)
                break

        if not applied_template:
            raise ValueError(f"Failed to apply any patch template for {vulnerability_type}")

        # Generate diff
        diff = self._generate_diff(file_path, original_code, patched_code)

        # Generate rollback instructions
        rollback = f"""
To rollback this patch:
1. Save the original code:
{original_code[:500]}{"..." if len(original_code) > 500 else ""}

2. Replace the patched section with the original code
3. Remove any added imports if not used elsewhere
4. Run tests to verify functionality
"""

        # Create patch object
        patch = GeneratedPatch(
            patch_id=self._generate_patch_id(vulnerability_id, vulnerability_type),
            vulnerability_id=vulnerability_id,
            vulnerability_type=vulnerability_type,
            patch_type=PatchType.CODE_FIX,
            language=language,
            framework=framework,
            title=f"Fix {vulnerability_type.replace('_', ' ').title()}",
            description=applied_template.description,
            diffs=[diff],
            validation_tests=validation_tests,
            rollback_instructions=rollback,
            breaking_changes=[],
            dependencies=applied_template.imports_required,
            confidence=applied_template.confidence_base,
            generated_at=datetime.utcnow(),
            generation_time_ms=int((time.time() - start_time) * 1000)
        )

        logger.info(
            f"Generated patch for {vulnerability_type} in {file_path} "
            f"({patch.generation_time_ms}ms)"
        )

        return patch

    async def generate_validation_suite(
        self,
        patch: GeneratedPatch,
        test_framework: str = "pytest"
    ) -> str:
        """
        Generate a complete validation test suite for a patch.

        Args:
            patch: Generated patch
            test_framework: Testing framework to use

        Returns:
            Complete test file content
        """
        if test_framework == "pytest":
            header = '''"""
Auto-generated validation tests for security patch.
Patch ID: {patch_id}
Vulnerability: {vuln_type}
Generated: {timestamp}
"""

import pytest
'''
        else:  # Jest/Mocha
            header = '''/**
 * Auto-generated validation tests for security patch.
 * Patch ID: {patch_id}
 * Vulnerability: {vuln_type}
 * Generated: {timestamp}
 */

'''

        header = header.format(
            patch_id=patch.patch_id,
            vuln_type=patch.vulnerability_type,
            timestamp=patch.generated_at.isoformat()
        )

        tests = "\n\n".join(patch.validation_tests)

        return header + "\n" + tests

    async def batch_generate(
        self,
        vulnerabilities: List[Dict[str, Any]]
    ) -> List[GeneratedPatch]:
        """
        Generate patches for multiple vulnerabilities.

        Args:
            vulnerabilities: List of vulnerability dicts

        Returns:
            List of generated patches
        """
        tasks = []
        for vuln in vulnerabilities:
            task = self.generate(
                vulnerability_id=vuln["id"],
                vulnerability_type=vuln["type"],
                original_code=vuln["code"],
                file_path=vuln["file_path"],
                language=PatchLanguage(vuln["language"]),
                framework=Framework(vuln["framework"]) if vuln.get("framework") else None,
                context=vuln.get("context", {})
            )
            tasks.append(task)

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Filter out exceptions
        patches = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"Failed to generate patch for vulnerability {i}: {result}")
            else:
                patches.append(result)

        return patches

    def get_supported_types(self) -> List[str]:
        """Get list of supported vulnerability types for patching."""
        return list(self._templates.keys())

    def get_supported_languages(self, vuln_type: str) -> List[PatchLanguage]:
        """Get supported languages for patching a vulnerability type."""
        templates = self._templates.get(vuln_type, [])
        return list(set(t.language for t in templates))

    def get_supported_frameworks(self, vuln_type: str, language: PatchLanguage) -> List[Framework]:
        """Get supported frameworks for a vulnerability type and language."""
        templates = self._templates.get(vuln_type, [])
        return [
            t.framework for t in templates
            if t.language == language and t.framework
        ]


# Export for convenience
__all__ = [
    "PatchGeneratorModel",
    "PatchGeneratorConfig",
    "GeneratedPatch",
    "CodeDiff",
    "PatchTemplate",
    "PatchLanguage",
    "Framework",
    "PatchType",
    "PatchStatus"
]
