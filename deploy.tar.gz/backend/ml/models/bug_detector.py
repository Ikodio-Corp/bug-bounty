"""
Bug Detector ML Model - 90-Second Promise Implementation

This module implements the core ML-based vulnerability detection system
that can identify security vulnerabilities in code within 90 seconds.
"""

import asyncio
import hashlib
import json
import logging
import re
import time
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime
from enum import Enum

import numpy as np
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class VulnerabilityType(str, Enum):
    """Enumeration of supported vulnerability types."""
    SQL_INJECTION = "sql_injection"
    XSS = "xss"
    COMMAND_INJECTION = "command_injection"
    PATH_TRAVERSAL = "path_traversal"
    SSRF = "ssrf"
    XXE = "xxe"
    DESERIALIZATION = "deserialization"
    BROKEN_AUTH = "broken_auth"
    SENSITIVE_DATA = "sensitive_data"
    SECURITY_MISCONFIG = "security_misconfig"
    IDOR = "idor"
    CSRF = "csrf"
    OPEN_REDIRECT = "open_redirect"
    FILE_UPLOAD = "file_upload"
    RACE_CONDITION = "race_condition"
    MEMORY_CORRUPTION = "memory_corruption"
    CRYPTO_WEAKNESS = "crypto_weakness"
    HARDCODED_SECRETS = "hardcoded_secrets"
    PROTOTYPE_POLLUTION = "prototype_pollution"
    TEMPLATE_INJECTION = "template_injection"


class SeverityLevel(str, Enum):
    """CVSS-based severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class DetectionResult(BaseModel):
    """Model for vulnerability detection results."""
    vulnerability_id: str
    vulnerability_type: VulnerabilityType
    severity: SeverityLevel
    confidence: float = Field(ge=0.0, le=1.0)
    title: str
    description: str
    file_path: str
    line_number: int
    code_snippet: str
    cwe_id: Optional[str] = None
    cvss_score: Optional[float] = None
    cvss_vector: Optional[str] = None
    remediation: str
    references: List[str] = []
    detected_at: datetime = Field(default_factory=datetime.utcnow)
    detection_time_ms: int = 0


class BugDetectorConfig(BaseModel):
    """Configuration for the bug detector."""
    max_file_size_kb: int = 1024
    timeout_seconds: int = 90
    min_confidence: float = 0.6
    enable_ai_analysis: bool = True
    enable_pattern_matching: bool = True
    enable_semantic_analysis: bool = True
    parallel_workers: int = 4
    model_version: str = "v1.0.0"


class PatternRule(BaseModel):
    """Pattern-based detection rule."""
    rule_id: str
    name: str
    pattern: str
    vulnerability_type: VulnerabilityType
    severity: SeverityLevel
    cwe_id: str
    description: str
    remediation: str
    languages: List[str]
    confidence_base: float = 0.7


class BugDetectorModel:
    """
    ML-based Bug Detector implementing the 90-second promise.

    This model combines:
    1. Pattern-based detection (fast, high precision)
    2. Semantic analysis using CodeBERT
    3. AI-powered deep analysis using GPT-4/Claude
    4. Ensemble voting for final results
    """

    def __init__(self, config: Optional[BugDetectorConfig] = None):
        """Initialize the bug detector with configuration."""
        self.config = config or BugDetectorConfig()
        self._patterns: List[PatternRule] = []
        self._model_loaded = False
        self._codebert_model = None
        self._tokenizer = None
        self._load_patterns()
        logger.info(f"BugDetectorModel initialized with version {self.config.model_version}")

    def _load_patterns(self) -> None:
        """Load vulnerability detection patterns."""
        self._patterns = [
            # SQL Injection patterns
            PatternRule(
                rule_id="SQLI-001",
                name="SQL Injection - String Concatenation",
                pattern=r"(?:execute|query|cursor\.execute)\s*\(\s*[\"'].*?\%s.*?[\"']\s*%\s*\(?[^)]+\)?",
                vulnerability_type=VulnerabilityType.SQL_INJECTION,
                severity=SeverityLevel.CRITICAL,
                cwe_id="CWE-89",
                description="SQL query constructed using string concatenation with user input",
                remediation="Use parameterized queries or prepared statements",
                languages=["python"],
                confidence_base=0.85
            ),
            PatternRule(
                rule_id="SQLI-002",
                name="SQL Injection - f-string",
                pattern=r"(?:execute|query)\s*\(\s*f[\"'].*?\{.*?\}.*?[\"']\s*\)",
                vulnerability_type=VulnerabilityType.SQL_INJECTION,
                severity=SeverityLevel.CRITICAL,
                cwe_id="CWE-89",
                description="SQL query constructed using f-string with variables",
                remediation="Use parameterized queries instead of f-strings",
                languages=["python"],
                confidence_base=0.9
            ),
            PatternRule(
                rule_id="SQLI-003",
                name="SQL Injection - JavaScript",
                pattern=r"(?:query|execute)\s*\(\s*[`\"'].*?\$\{.*?\}.*?[`\"']\s*\)",
                vulnerability_type=VulnerabilityType.SQL_INJECTION,
                severity=SeverityLevel.CRITICAL,
                cwe_id="CWE-89",
                description="SQL query with template literal injection",
                remediation="Use parameterized queries with placeholders",
                languages=["javascript", "typescript"],
                confidence_base=0.85
            ),
            # XSS patterns
            PatternRule(
                rule_id="XSS-001",
                name="XSS - innerHTML Assignment",
                pattern=r"\.innerHTML\s*=\s*(?!.*(?:sanitize|escape|encode)).*",
                vulnerability_type=VulnerabilityType.XSS,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-79",
                description="Direct innerHTML assignment without sanitization",
                remediation="Use textContent or sanitize HTML before assignment",
                languages=["javascript", "typescript"],
                confidence_base=0.75
            ),
            PatternRule(
                rule_id="XSS-002",
                name="XSS - document.write",
                pattern=r"document\.write\s*\(.*\)",
                vulnerability_type=VulnerabilityType.XSS,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-79",
                description="Use of document.write can lead to XSS",
                remediation="Use DOM manipulation methods instead",
                languages=["javascript", "typescript"],
                confidence_base=0.7
            ),
            PatternRule(
                rule_id="XSS-003",
                name="XSS - eval with user input",
                pattern=r"eval\s*\(\s*(?:req|request|params|query|body|input).*\)",
                vulnerability_type=VulnerabilityType.XSS,
                severity=SeverityLevel.CRITICAL,
                cwe_id="CWE-79",
                description="eval() called with potentially user-controlled input",
                remediation="Never use eval with user input; use safe alternatives",
                languages=["javascript", "typescript", "python"],
                confidence_base=0.9
            ),
            # Command Injection patterns
            PatternRule(
                rule_id="CMDI-001",
                name="Command Injection - os.system",
                pattern=r"os\.system\s*\(\s*(?:f[\"']|[\"'].*?\%|.*?\+).*\)",
                vulnerability_type=VulnerabilityType.COMMAND_INJECTION,
                severity=SeverityLevel.CRITICAL,
                cwe_id="CWE-78",
                description="os.system called with user-controlled input",
                remediation="Use subprocess with shell=False and argument list",
                languages=["python"],
                confidence_base=0.85
            ),
            PatternRule(
                rule_id="CMDI-002",
                name="Command Injection - subprocess shell=True",
                pattern=r"subprocess\.(?:call|run|Popen)\s*\([^)]*shell\s*=\s*True[^)]*\)",
                vulnerability_type=VulnerabilityType.COMMAND_INJECTION,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-78",
                description="subprocess called with shell=True",
                remediation="Use shell=False with command as list",
                languages=["python"],
                confidence_base=0.8
            ),
            PatternRule(
                rule_id="CMDI-003",
                name="Command Injection - child_process",
                pattern=r"(?:exec|execSync|spawn)\s*\(\s*(?:`.*\$\{|.*\+).*\)",
                vulnerability_type=VulnerabilityType.COMMAND_INJECTION,
                severity=SeverityLevel.CRITICAL,
                cwe_id="CWE-78",
                description="child_process with concatenated command",
                remediation="Use spawn with argument array",
                languages=["javascript", "typescript"],
                confidence_base=0.85
            ),
            # Path Traversal patterns
            PatternRule(
                rule_id="PATH-001",
                name="Path Traversal - open with user input",
                pattern=r"open\s*\(\s*(?:f[\"']|.*?\+|.*?%|.*?\.format).*\)",
                vulnerability_type=VulnerabilityType.PATH_TRAVERSAL,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-22",
                description="File open with potentially user-controlled path",
                remediation="Validate and sanitize file paths; use os.path.basename",
                languages=["python"],
                confidence_base=0.7
            ),
            PatternRule(
                rule_id="PATH-002",
                name="Path Traversal - fs operations",
                pattern=r"(?:readFile|writeFile|readdir|unlink)\s*\(\s*(?:`.*\$\{|.*\+).*\)",
                vulnerability_type=VulnerabilityType.PATH_TRAVERSAL,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-22",
                description="File system operation with user input",
                remediation="Use path.resolve and validate against allowed directories",
                languages=["javascript", "typescript"],
                confidence_base=0.75
            ),
            # SSRF patterns
            PatternRule(
                rule_id="SSRF-001",
                name="SSRF - requests with user URL",
                pattern=r"requests\.(?:get|post|put|delete)\s*\(\s*(?:f[\"']|.*?\+|.*?%|.*?\.format).*\)",
                vulnerability_type=VulnerabilityType.SSRF,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-918",
                description="HTTP request with user-controlled URL",
                remediation="Validate URLs against allowlist; block internal IPs",
                languages=["python"],
                confidence_base=0.8
            ),
            PatternRule(
                rule_id="SSRF-002",
                name="SSRF - fetch/axios with user URL",
                pattern=r"(?:fetch|axios\.(?:get|post))\s*\(\s*(?:`.*\$\{|.*\+).*\)",
                vulnerability_type=VulnerabilityType.SSRF,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-918",
                description="HTTP request with user-controlled URL",
                remediation="Validate URLs and block internal networks",
                languages=["javascript", "typescript"],
                confidence_base=0.8
            ),
            # XXE patterns
            PatternRule(
                rule_id="XXE-001",
                name="XXE - Unsafe XML parsing",
                pattern=r"(?:etree\.parse|minidom\.parse|xml\.sax\.parse)\s*\(",
                vulnerability_type=VulnerabilityType.XXE,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-611",
                description="XML parsing without disabling external entities",
                remediation="Use defusedxml or disable external entity processing",
                languages=["python"],
                confidence_base=0.7
            ),
            # Deserialization patterns
            PatternRule(
                rule_id="DESER-001",
                name="Unsafe Deserialization - pickle",
                pattern=r"pickle\.(?:load|loads)\s*\(",
                vulnerability_type=VulnerabilityType.DESERIALIZATION,
                severity=SeverityLevel.CRITICAL,
                cwe_id="CWE-502",
                description="Unsafe pickle deserialization",
                remediation="Use JSON or other safe serialization formats",
                languages=["python"],
                confidence_base=0.85
            ),
            PatternRule(
                rule_id="DESER-002",
                name="Unsafe Deserialization - yaml",
                pattern=r"yaml\.(?:load|unsafe_load)\s*\([^)]*(?!Loader\s*=\s*yaml\.SafeLoader)",
                vulnerability_type=VulnerabilityType.DESERIALIZATION,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-502",
                description="YAML load without SafeLoader",
                remediation="Use yaml.safe_load or specify SafeLoader",
                languages=["python"],
                confidence_base=0.8
            ),
            # Hardcoded Secrets patterns
            PatternRule(
                rule_id="SECRET-001",
                name="Hardcoded API Key",
                pattern=r"(?:api_key|apikey|api_secret|secret_key)\s*=\s*[\"'][a-zA-Z0-9]{20,}[\"']",
                vulnerability_type=VulnerabilityType.HARDCODED_SECRETS,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-798",
                description="Hardcoded API key or secret",
                remediation="Use environment variables or secret management",
                languages=["python", "javascript", "typescript"],
                confidence_base=0.85
            ),
            PatternRule(
                rule_id="SECRET-002",
                name="Hardcoded Password",
                pattern=r"(?:password|passwd|pwd)\s*=\s*[\"'][^\"']{8,}[\"']",
                vulnerability_type=VulnerabilityType.HARDCODED_SECRETS,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-798",
                description="Hardcoded password in source code",
                remediation="Use environment variables or secret vault",
                languages=["python", "javascript", "typescript", "java"],
                confidence_base=0.75
            ),
            PatternRule(
                rule_id="SECRET-003",
                name="Hardcoded AWS Credentials",
                pattern=r"(?:AKIA|ASIA)[A-Z0-9]{16}",
                vulnerability_type=VulnerabilityType.HARDCODED_SECRETS,
                severity=SeverityLevel.CRITICAL,
                cwe_id="CWE-798",
                description="AWS access key ID in source code",
                remediation="Use IAM roles or AWS Secrets Manager",
                languages=["python", "javascript", "typescript", "java", "go"],
                confidence_base=0.95
            ),
            # Crypto Weakness patterns
            PatternRule(
                rule_id="CRYPTO-001",
                name="Weak Hash Algorithm - MD5",
                pattern=r"(?:hashlib\.md5|MD5|Digest::MD5)",
                vulnerability_type=VulnerabilityType.CRYPTO_WEAKNESS,
                severity=SeverityLevel.MEDIUM,
                cwe_id="CWE-328",
                description="Use of weak MD5 hash algorithm",
                remediation="Use SHA-256 or stronger hash functions",
                languages=["python", "javascript", "ruby"],
                confidence_base=0.8
            ),
            PatternRule(
                rule_id="CRYPTO-002",
                name="Weak Hash Algorithm - SHA1",
                pattern=r"(?:hashlib\.sha1|SHA1|Digest::SHA1)",
                vulnerability_type=VulnerabilityType.CRYPTO_WEAKNESS,
                severity=SeverityLevel.MEDIUM,
                cwe_id="CWE-328",
                description="Use of weak SHA1 hash algorithm",
                remediation="Use SHA-256 or stronger hash functions",
                languages=["python", "javascript", "ruby"],
                confidence_base=0.75
            ),
            # CSRF patterns
            PatternRule(
                rule_id="CSRF-001",
                name="Missing CSRF Protection",
                pattern=r"@app\.(?:post|put|delete|patch)\s*\([^)]*\)\s*(?:async\s+)?def\s+\w+\s*\([^)]*\):\s*(?!\s*.*csrf)",
                vulnerability_type=VulnerabilityType.CSRF,
                severity=SeverityLevel.MEDIUM,
                cwe_id="CWE-352",
                description="State-changing endpoint without CSRF protection",
                remediation="Implement CSRF tokens for state-changing operations",
                languages=["python"],
                confidence_base=0.6
            ),
            # Open Redirect patterns
            PatternRule(
                rule_id="REDIRECT-001",
                name="Open Redirect",
                pattern=r"(?:redirect|RedirectResponse)\s*\(\s*(?:request\.|req\.|params\.|query\.)",
                vulnerability_type=VulnerabilityType.OPEN_REDIRECT,
                severity=SeverityLevel.MEDIUM,
                cwe_id="CWE-601",
                description="Redirect using user-controlled URL",
                remediation="Validate redirect URLs against allowlist",
                languages=["python", "javascript"],
                confidence_base=0.75
            ),
            # File Upload patterns
            PatternRule(
                rule_id="UPLOAD-001",
                name="Unsafe File Upload",
                pattern=r"(?:save|write|upload).*?(?:filename|name)\s*=\s*(?:file|request|req)\.(?:filename|name)",
                vulnerability_type=VulnerabilityType.FILE_UPLOAD,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-434",
                description="File upload without proper validation",
                remediation="Validate file type, size, and sanitize filename",
                languages=["python", "javascript"],
                confidence_base=0.7
            ),
            # Prototype Pollution patterns
            PatternRule(
                rule_id="PROTO-001",
                name="Prototype Pollution",
                pattern=r"(?:Object\.assign|_\.merge|_\.extend|_\.defaultsDeep)\s*\([^,]*,\s*(?:req|request|params|body|input)",
                vulnerability_type=VulnerabilityType.PROTOTYPE_POLLUTION,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-1321",
                description="Object merge with user-controlled input",
                remediation="Validate input keys; use Object.create(null)",
                languages=["javascript", "typescript"],
                confidence_base=0.8
            ),
            # Template Injection patterns
            PatternRule(
                rule_id="SSTI-001",
                name="Server-Side Template Injection",
                pattern=r"(?:render_template_string|Template)\s*\(\s*(?:f[\"']|.*?\+|.*?%|.*?\.format).*\)",
                vulnerability_type=VulnerabilityType.TEMPLATE_INJECTION,
                severity=SeverityLevel.CRITICAL,
                cwe_id="CWE-1336",
                description="Template rendered with user input",
                remediation="Use static templates; escape user input",
                languages=["python"],
                confidence_base=0.85
            ),
            # IDOR patterns
            PatternRule(
                rule_id="IDOR-001",
                name="Insecure Direct Object Reference",
                pattern=r"(?:get|find|delete|update).*?\(\s*(?:id|user_id|account_id)\s*=\s*(?:request|req|params)",
                vulnerability_type=VulnerabilityType.IDOR,
                severity=SeverityLevel.HIGH,
                cwe_id="CWE-639",
                description="Direct object access without authorization check",
                remediation="Implement proper authorization checks",
                languages=["python", "javascript"],
                confidence_base=0.65
            ),
        ]
        logger.info(f"Loaded {len(self._patterns)} vulnerability detection patterns")

    async def load_models(self) -> None:
        """Load ML models for semantic analysis."""
        if self._model_loaded:
            return

        try:
            # Attempt to load CodeBERT for semantic analysis
            # This is optional and will gracefully degrade if not available
            try:
                from transformers import AutoTokenizer, AutoModel
                self._tokenizer = AutoTokenizer.from_pretrained("microsoft/codebert-base")
                self._codebert_model = AutoModel.from_pretrained("microsoft/codebert-base")
                logger.info("CodeBERT model loaded successfully")
            except Exception as e:
                logger.warning(f"CodeBERT not available, using pattern-based detection only: {e}")

            self._model_loaded = True
            logger.info("Bug detector models loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load models: {e}")
            raise

    def _detect_language(self, file_path: str, code: str) -> str:
        """Detect programming language from file extension or content."""
        extension_map = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".tsx": "typescript",
            ".jsx": "javascript",
            ".java": "java",
            ".go": "go",
            ".rb": "ruby",
            ".php": "php",
            ".cs": "csharp",
            ".cpp": "cpp",
            ".c": "c",
            ".rs": "rust",
        }

        for ext, lang in extension_map.items():
            if file_path.endswith(ext):
                return lang

        # Fallback to content-based detection
        if "def " in code and "import " in code:
            return "python"
        elif "function " in code or "const " in code:
            return "javascript"

        return "unknown"

    def _generate_vulnerability_id(self, vuln_type: str, file_path: str, line: int) -> str:
        """Generate unique vulnerability ID."""
        content = f"{vuln_type}:{file_path}:{line}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def _extract_code_snippet(self, code: str, line_number: int, context_lines: int = 3) -> str:
        """Extract code snippet around the vulnerable line."""
        lines = code.split("\n")
        start = max(0, line_number - context_lines - 1)
        end = min(len(lines), line_number + context_lines)

        snippet_lines = []
        for i in range(start, end):
            prefix = ">>> " if i == line_number - 1 else "    "
            snippet_lines.append(f"{i + 1:4d} {prefix}{lines[i]}")

        return "\n".join(snippet_lines)

    def _calculate_cvss_score(self, severity: SeverityLevel, vuln_type: VulnerabilityType) -> Tuple[float, str]:
        """Calculate CVSS score and vector based on vulnerability type."""
        # Base CVSS v3.1 vectors for common vulnerability types
        cvss_map = {
            VulnerabilityType.SQL_INJECTION: (9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"),
            VulnerabilityType.COMMAND_INJECTION: (9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"),
            VulnerabilityType.XSS: (6.1, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N"),
            VulnerabilityType.SSRF: (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N"),
            VulnerabilityType.PATH_TRAVERSAL: (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N"),
            VulnerabilityType.XXE: (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N"),
            VulnerabilityType.DESERIALIZATION: (9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"),
            VulnerabilityType.HARDCODED_SECRETS: (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N"),
            VulnerabilityType.CRYPTO_WEAKNESS: (5.3, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N"),
            VulnerabilityType.CSRF: (4.3, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:L/A:N"),
            VulnerabilityType.OPEN_REDIRECT: (4.7, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:N/I:L/A:N"),
            VulnerabilityType.FILE_UPLOAD: (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:H/A:N"),
            VulnerabilityType.IDOR: (6.5, "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N"),
            VulnerabilityType.TEMPLATE_INJECTION: (9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"),
            VulnerabilityType.PROTOTYPE_POLLUTION: (7.3, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:L"),
        }

        return cvss_map.get(vuln_type, (5.0, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N"))

    async def _pattern_based_detection(
        self,
        code: str,
        file_path: str,
        language: str
    ) -> List[DetectionResult]:
        """Perform pattern-based vulnerability detection."""
        results = []
        lines = code.split("\n")

        for pattern_rule in self._patterns:
            # Skip patterns not applicable to this language
            if language not in pattern_rule.languages and language != "unknown":
                continue

            try:
                regex = re.compile(pattern_rule.pattern, re.IGNORECASE | re.MULTILINE)

                for match in regex.finditer(code):
                    # Calculate line number
                    line_number = code[:match.start()].count("\n") + 1

                    # Calculate CVSS
                    cvss_score, cvss_vector = self._calculate_cvss_score(
                        pattern_rule.severity,
                        pattern_rule.vulnerability_type
                    )

                    result = DetectionResult(
                        vulnerability_id=self._generate_vulnerability_id(
                            pattern_rule.vulnerability_type.value,
                            file_path,
                            line_number
                        ),
                        vulnerability_type=pattern_rule.vulnerability_type,
                        severity=pattern_rule.severity,
                        confidence=pattern_rule.confidence_base,
                        title=pattern_rule.name,
                        description=pattern_rule.description,
                        file_path=file_path,
                        line_number=line_number,
                        code_snippet=self._extract_code_snippet(code, line_number),
                        cwe_id=pattern_rule.cwe_id,
                        cvss_score=cvss_score,
                        cvss_vector=cvss_vector,
                        remediation=pattern_rule.remediation,
                        references=[
                            f"https://cwe.mitre.org/data/definitions/{pattern_rule.cwe_id.split('-')[1]}.html"
                        ]
                    )
                    results.append(result)

            except re.error as e:
                logger.warning(f"Invalid regex pattern {pattern_rule.rule_id}: {e}")
                continue

        return results

    async def _semantic_analysis(
        self,
        code: str,
        file_path: str,
        language: str
    ) -> List[DetectionResult]:
        """Perform semantic analysis using CodeBERT."""
        results = []

        if not self._codebert_model or not self._tokenizer:
            return results

        try:
            # Tokenize code
            inputs = self._tokenizer(
                code,
                return_tensors="pt",
                truncation=True,
                max_length=512
            )

            # Get embeddings
            outputs = self._codebert_model(**inputs)
            embeddings = outputs.last_hidden_state.mean(dim=1)

            # Here we would compare against known vulnerability patterns
            # This is a placeholder for actual semantic vulnerability detection
            # In production, this would use trained classifiers

        except Exception as e:
            logger.warning(f"Semantic analysis failed: {e}")

        return results

    async def detect(
        self,
        code: str,
        file_path: str,
        language: Optional[str] = None
    ) -> List[DetectionResult]:
        """
        Detect vulnerabilities in code using pattern matching and ML analysis.

        Args:
            code: Source code to analyze
            file_path: Path to the file being analyzed
            language: Programming language (auto-detected if not provided)

        Returns:
            List of detected vulnerabilities
        """
        start_time = time.time()

        # Auto-detect language if not provided
        if not language:
            language = self._detect_language(file_path, code)

        results = []

        # Run pattern-based detection
        if self.config.enable_pattern_matching:
            pattern_results = await self._pattern_based_detection(code, file_path, language)
            results.extend(pattern_results)

        # Run semantic analysis
        if self.config.enable_semantic_analysis and self._model_loaded:
            semantic_results = await self._semantic_analysis(code, file_path, language)
            results.extend(semantic_results)

        # Filter by minimum confidence
        results = [r for r in results if r.confidence >= self.config.min_confidence]

        # Remove duplicates based on vulnerability ID
        seen_ids = set()
        unique_results = []
        for result in results:
            if result.vulnerability_id not in seen_ids:
                seen_ids.add(result.vulnerability_id)
                unique_results.append(result)

        # Add detection time
        detection_time_ms = int((time.time() - start_time) * 1000)
        for result in unique_results:
            result.detection_time_ms = detection_time_ms

        logger.info(
            f"Detected {len(unique_results)} vulnerabilities in {file_path} "
            f"({detection_time_ms}ms)"
        )

        return unique_results

    async def batch_detect(
        self,
        files: List[Dict[str, str]],
        max_workers: Optional[int] = None
    ) -> Dict[str, List[DetectionResult]]:
        """
        Detect vulnerabilities in multiple files concurrently.

        Args:
            files: List of dicts with 'path' and 'content' keys
            max_workers: Maximum concurrent workers

        Returns:
            Dict mapping file paths to detection results
        """
        max_workers = max_workers or self.config.parallel_workers
        results = {}

        semaphore = asyncio.Semaphore(max_workers)

        async def process_file(file_info: Dict[str, str]) -> Tuple[str, List[DetectionResult]]:
            async with semaphore:
                file_path = file_info["path"]
                content = file_info["content"]

                # Check file size
                if len(content) > self.config.max_file_size_kb * 1024:
                    logger.warning(f"Skipping {file_path}: exceeds size limit")
                    return file_path, []

                try:
                    detections = await asyncio.wait_for(
                        self.detect(content, file_path),
                        timeout=self.config.timeout_seconds
                    )
                    return file_path, detections
                except asyncio.TimeoutError:
                    logger.warning(f"Timeout detecting vulnerabilities in {file_path}")
                    return file_path, []
                except Exception as e:
                    logger.error(f"Error processing {file_path}: {e}")
                    return file_path, []

        tasks = [process_file(f) for f in files]
        completed = await asyncio.gather(*tasks)

        for file_path, detections in completed:
            results[file_path] = detections

        return results

    def get_statistics(self, results: List[DetectionResult]) -> Dict[str, Any]:
        """Generate statistics from detection results."""
        if not results:
            return {
                "total": 0,
                "by_severity": {},
                "by_type": {},
                "average_confidence": 0.0
            }

        by_severity = {}
        by_type = {}
        total_confidence = 0.0

        for result in results:
            # Count by severity
            severity = result.severity.value
            by_severity[severity] = by_severity.get(severity, 0) + 1

            # Count by type
            vuln_type = result.vulnerability_type.value
            by_type[vuln_type] = by_type.get(vuln_type, 0) + 1

            total_confidence += result.confidence

        return {
            "total": len(results),
            "by_severity": by_severity,
            "by_type": by_type,
            "average_confidence": total_confidence / len(results),
            "critical_count": by_severity.get("critical", 0),
            "high_count": by_severity.get("high", 0),
            "medium_count": by_severity.get("medium", 0),
            "low_count": by_severity.get("low", 0)
        }


# Export for convenience
__all__ = [
    "BugDetectorModel",
    "BugDetectorConfig",
    "DetectionResult",
    "VulnerabilityType",
    "SeverityLevel",
    "PatternRule"
]
