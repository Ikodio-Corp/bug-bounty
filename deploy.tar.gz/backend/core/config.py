"""
IKODIO BugBounty Platform - Configuration
All 70 ideas configuration settings
"""

from pydantic_settings import BaseSettings
from typing import List
import os
from dotenv import load_dotenv

# Load .env file
load_dotenv()


class Settings(BaseSettings):
    # Application
    APP_NAME: str = "IKODIO BugBounty"
    PROJECT_NAME: str = "IKODIO BugBounty Platform"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"
    ENVIRONMENT: str = "production"
    
    # Database
    DB_HOST: str = "postgres"
    DB_PORT: int = 5432
    DB_NAME: str = "ikodio_bugbounty"
    DB_USER: str = "ikodio"
    DB_PASSWORD: str = "changeme"
    
    @property
    def DATABASE_URL(self) -> str:
        return f"postgresql://{self.DB_USER}:{self.DB_PASSWORD}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
    
    # Database Sharding
    ENABLE_SHARDING: bool = False
    DATABASE_URL_SHARD_0: str = ""
    DATABASE_URL_SHARD_1: str = ""
    DATABASE_URL_SHARD_2: str = ""
    
    # Redis
    REDIS_HOST: str = "redis"
    REDIS_PORT: int = 6379
    REDIS_URL: str = "redis://redis:6379/0"
    
    # RabbitMQ
    RABBITMQ_HOST: str = "rabbitmq"
    RABBITMQ_PORT: int = 5672
    RABBITMQ_USER: str = "ikodio"
    RABBITMQ_PASSWORD: str = "changeme"
    RABBITMQ_URL: str = "amqp://guest:guest@rabbitmq:5672/"
    
    # Elasticsearch
    ELASTICSEARCH_HOST: str = "elasticsearch"
    ELASTICSEARCH_PORT: int = 9200
    
    # Security
    JWT_SECRET: str = "changeme-jwt-secret"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION: int = 3600
    ENCRYPTION_KEY: str = "changeme-encryption-key"
    SECRET_KEY: str = "changeme-secret-key"
    
    # AI Services
    OPENAI_API_KEY: str = "sk-placeholder"
    ANTHROPIC_API_KEY: str = ""
    AI_MODEL: str = "gpt-4-turbo-preview"
    AI_TEMPERATURE: float = 0.3
    AI_MAX_TOKENS: int = 4000
    AI_AGENT_COUNT: int = 1000
    
    # Bug Bounty Platforms
    HACKERONE_API_KEY: str = ""
    HACKERONE_USERNAME: str = ""
    BUGCROWD_API_KEY: str = ""
    INTIGRITI_API_KEY: str = ""
    YESWEHACK_API_KEY: str = ""
    
    # Feature Flags - All 70 Ideas
    ENABLE_AI: bool = True
    ENABLE_AI_AGENTS: bool = True
    ENABLE_GPU: bool = False
    ENABLE_QUANTUM: bool = False
    ENABLE_SATELLITE: bool = False
    ENABLE_MARKETPLACE: bool = True
    ENABLE_NFT: bool = False
    ENABLE_DAO: bool = False
    ENABLE_GUILD: bool = True
    ENABLE_UNIVERSITY: bool = True
    ENABLE_UNIVERSITY_PROGRAM: bool = True
    ENABLE_NATION_STATE: bool = False
    ENABLE_SANCTIONS: bool = False
    ENABLE_ESG: bool = True
    ENABLE_GEOPOLITICAL: bool = True
    ENABLE_CELEBRITY: bool = False
    ENABLE_REALITY_SHOW: bool = False
    
    # Scanning Configuration
    MAX_CONCURRENT_SCANS: int = 100
    SCAN_TIMEOUT: int = 300
    MAX_AGENTS_PER_SCAN: int = 1000
    DISCOVERY_TIME_LIMIT: int = 90
    VALIDATION_TIME_LIMIT: int = 20
    REPORTING_TIME_LIMIT: int = 20
    
    # Network
    EXTERNAL_IP: str = "0.0.0.0"
    DOMAIN: str = "bugbounty.ikodio.com"
    API_PORT: int = 8000
    FRONTEND_PORT: int = 3000
    SSL_ENABLED: bool = True
    
    # CORS
    ENABLE_CORS: bool = True
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:3002,http://192.168.100.6:3002,https://bugbounty.ikodio.com"
    
    # API Documentation
    ENABLE_API_DOCS: bool = True
    
    # Marketplace
    MARKETPLACE_FEE_PERCENTAGE: float = 20.0
    FIX_REFERRAL_FEE: float = 30.0
    PRIVATE_BUG_PREMIUM_MULTIPLIER: float = 2.0
    SPEED_BONUS_PERCENTAGE: float = 20.0
    
    # Data Products
    SECURITY_SCORE_PRICE_MIN: int = 5000
    SECURITY_SCORE_PRICE_MAX: int = 20000
    VULNERABILITY_FORECAST_SUBSCRIPTION: int = 50000
    DATABASE_LICENSE_ANNUAL: int = 100000
    
    # Subscriptions
    SUBSCRIPTION_FREE_SCANS_PER_MONTH: int = 10
    SUBSCRIPTION_BRONZE_PRICE: int = 10
    SUBSCRIPTION_SILVER_PRICE: int = 50
    SUBSCRIPTION_GOLD_PRICE: int = 500
    SUBSCRIPTION_PLATINUM_PRICE: int = 5000
    
    # Guild
    GUILD_MEMBERSHIP_FEE_PERCENTAGE: float = 2.0
    GUILD_MIN_FEE_ANNUAL: int = 100
    GUILD_MAX_FEE_ANNUAL: int = 20000
    
    # University
    UNIVERSITY_CURRICULUM_LICENSE: int = 50000
    STUDENT_PLATFORM_FEE: int = 20
    CERTIFICATION_EXAM_FEE: int = 500
    RECRUITING_PLACEMENT_FEE: int = 10000
    
    # Geopolitical
    NATION_STATE_CONTRACT_MIN: int = 5000000
    VULNERABILITY_SANCTIONS_ENABLED: bool = False
    ESG_SCORING_ENABLED: bool = True
    
    # Quantum & R&D
    QUANTUM_API_ENDPOINT: str = "https://quantum.ibm.com"
    QUANTUM_API_KEY: str = ""
    SATELLITE_DATA_LICENSE_KEY: str = ""
    AGI_RESEARCH_BUDGET: int = 10000000
    
    # Payments
    STRIPE_PUBLIC_KEY: str = ""
    STRIPE_SECRET_KEY: str = ""
    CRYPTO_WALLET_ADDRESS: str = ""
    
    # Email
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    EMAIL_FROM: str = "noreply@ikodio.com"
    
    # Monitoring
    GRAFANA_ADMIN_USER: str = "admin"
    GRAFANA_ADMIN_PASSWORD: str = ""
    GRAFANA_PASSWORD: str = ""
    SENTRY_DSN: str = ""
    
    # Performance
    WORKER_CONCURRENCY: int = 4
    RATE_LIMIT_PER_MINUTE: int = 100
    
    # PWA
    NEXT_PUBLIC_VAPID_PUBLIC_KEY: str = ""
    VAPID_PRIVATE_KEY: str = ""
    
    # Backup
    BACKUP_ENABLED: bool = True
    BACKUP_RETENTION_DAYS: int = 7
    
    # Social
    DISCORD_BOT_TOKEN: str = ""
    TWITTER_API_KEY: str = ""
    LINKEDIN_API_KEY: str = ""
    TIKTOK_API_KEY: str = ""
    
    # Compliance
    GDPR_ENABLED: bool = True
    DATA_RETENTION_DAYS: int = 365
    AUDIT_LOG_ENABLED: bool = True
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True
        extra = "allow"


settings = Settings()
