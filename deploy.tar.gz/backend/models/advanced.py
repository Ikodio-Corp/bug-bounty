"""
Advanced features models - Quantum, Satellite, AGI, Geopolitical
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, Text, JSON, ForeignKey
from datetime import datetime

from core.database import Base


class QuantumJob(Base):
    __tablename__ = "quantum_jobs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    job_type = Column(String(100), nullable=False)
    
    target_url = Column(String(1000))
    target_tech = Column(String(255))
    
    quantum_algorithm = Column(String(100))
    quantum_provider = Column(String(50))
    
    circuit_depth = Column(Integer)
    qubit_count = Column(Integer)
    
    status = Column(String(50), default="queued")
    
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    execution_time_seconds = Column(Integer)
    
    results = Column(JSON)
    vulnerabilities_found = Column(JSON)
    
    cost = Column(Float)
    
    error_message = Column(Text)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class SatelliteIntelligence(Base):
    __tablename__ = "satellite_intelligence"
    
    id = Column(Integer, primary_key=True, index=True)
    
    target_company = Column(String(255), nullable=False)
    target_location = Column(String(255))
    
    latitude = Column(Float)
    longitude = Column(Float)
    
    facility_type = Column(String(100))
    facility_size = Column(Float)
    
    imagery_date = Column(DateTime)
    imagery_provider = Column(String(100))
    imagery_url = Column(String(500))
    
    analysis = Column(Text)
    infrastructure_detected = Column(JSON)
    
    network_expansions = Column(JSON)
    new_deployments = Column(JSON)
    
    risk_assessment = Column(Text)
    recommendations = Column(Text)
    
    correlation_with_cyber = Column(JSON)
    
    confidence_score = Column(Float)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class AGIResearchLog(Base):
    __tablename__ = "agi_research_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    
    experiment_name = Column(String(255), nullable=False)
    experiment_type = Column(String(100))
    
    model_architecture = Column(String(255))
    model_parameters = Column(JSON)
    
    training_data_size = Column(Integer)
    training_duration = Column(Integer)
    
    performance_metrics = Column(JSON)
    
    bugs_discovered = Column(Integer, default=0)
    novel_vulnerabilities = Column(Integer, default=0)
    
    success_rate = Column(Float)
    false_positive_rate = Column(Float)
    
    insights = Column(Text)
    limitations = Column(Text)
    next_steps = Column(Text)
    
    budget_used = Column(Float)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class GeopoliticalContract(Base):
    __tablename__ = "geopolitical_contracts"
    
    id = Column(Integer, primary_key=True, index=True)
    
    contract_type = Column(String(100), nullable=False)
    
    government_entity = Column(String(255), nullable=False)
    country = Column(String(100), nullable=False)
    
    contract_value = Column(Float, nullable=False)
    currency = Column(String(10), default="USD")
    
    scope = Column(Text)
    deliverables = Column(JSON)
    
    classification_level = Column(String(50))
    
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)
    
    status = Column(String(50), default="active")
    
    bugs_delivered = Column(Integer, default=0)
    reports_delivered = Column(Integer, default=0)
    
    payment_schedule = Column(JSON)
    payments_received = Column(JSON)
    
    is_confidential = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SanctionTarget(Base):
    __tablename__ = "sanction_targets"
    
    id = Column(Integer, primary_key=True, index=True)
    
    target_company = Column(String(255), nullable=False)
    target_domain = Column(String(255), nullable=False)
    
    issue_type = Column(String(100), nullable=False)
    issue_description = Column(Text)
    
    evidence = Column(JSON)
    
    vulnerabilities_found = Column(JSON)
    leverage_points = Column(JSON)
    
    campaign_status = Column(String(50), default="active")
    
    partner_ngos = Column(JSON)
    media_coverage = Column(JSON)
    
    deadline = Column(DateTime)
    
    outcome = Column(String(50))
    outcome_description = Column(Text)
    
    impact_metrics = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ESGScore(Base):
    __tablename__ = "esg_scores"
    
    id = Column(Integer, primary_key=True, index=True)
    
    company_name = Column(String(255), nullable=False)
    ticker = Column(String(20))
    
    environmental_score = Column(Float)
    social_score = Column(Float)
    governance_score = Column(Float)
    overall_esg_score = Column(Float, nullable=False)
    
    security_score = Column(Float)
    security_weight = Column(Float)
    
    vulnerabilities_impact = Column(JSON)
    data_breach_history = Column(JSON)
    
    cybersecurity_investment = Column(Float)
    security_certifications = Column(JSON)
    
    report_url = Column(String(500))
    
    rating_date = Column(DateTime, nullable=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class DAOGovernance(Base):
    __tablename__ = "dao_governance_old"
    
    id = Column(Integer, primary_key=True, index=True)
    
    token_symbol = Column(String(10), nullable=False, unique=True)
    token_name = Column(String(100), nullable=False)
    
    total_supply = Column(Float, nullable=False)
    circulating_supply = Column(Float)
    
    token_price = Column(Float)
    market_cap = Column(Float)
    
    treasury_balance = Column(Float)
    treasury_assets = Column(JSON)
    
    bug_portfolio_value = Column(Float)
    
    total_holders = Column(Integer, default=0)
    
    governance_proposals = Column(JSON)
    
    revenue_30d = Column(Float)
    revenue_ytd = Column(Float)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class BCISecurityAudit(Base):
    __tablename__ = "bci_security_audits"
    
    id = Column(Integer, primary_key=True, index=True)
    
    device_manufacturer = Column(String(255), nullable=False)
    device_model = Column(String(255), nullable=False)
    
    firmware_version = Column(String(100))
    
    audit_type = Column(String(100))
    
    vulnerabilities_found = Column(JSON)
    
    neural_data_privacy_score = Column(Float)
    device_security_score = Column(Float)
    authentication_score = Column(Float)
    
    recommendations = Column(JSON)
    
    audit_date = Column(DateTime, nullable=False)
    auditor_id = Column(Integer, ForeignKey("users.id"))
    
    report_url = Column(String(500))
    
    is_confidential = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
