from sqlalchemy import Column, Integer, String, BigInteger, DateTime, Text, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
from core.database import Base


class Report(Base):
    """Report model for generated security reports"""
    
    __tablename__ = "reports"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    type = Column(String(50), nullable=False, index=True)  # security, vulnerability, compliance, scan
    title = Column(String(255), nullable=False)
    status = Column(String(50), default="generating", index=True)  # generating, ready, failed
    format = Column(String(20), default="pdf")  # pdf, csv, json
    date_range_days = Column(Integer, nullable=False)
    file_path = Column(String(500), nullable=True)
    file_size = Column(BigInteger, nullable=True)
    data = Column(JSONB, nullable=True)
    error_message = Column(Text, nullable=True)
    download_count = Column(Integer, default=0)
    generated_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="reports")
    
    def __repr__(self):
        return f"<Report {self.title} - {self.status}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "type": self.type,
            "title": self.title,
            "status": self.status,
            "format": self.format,
            "date_range_days": self.date_range_days,
            "file_path": self.file_path,
            "file_size": self.file_size,
            "data": self.data,
            "error_message": self.error_message,
            "download_count": self.download_count,
            "generated_at": self.generated_at.isoformat() if self.generated_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }
