"""
DevOps Autopilot Models
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text, JSON, ForeignKey, Enum as SQLEnum
from datetime import datetime
from enum import Enum

from core.database import Base


class AutomationJobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class DevOpsAutomationJob(Base):
    __tablename__ = "devops_automation_jobs"
    
    id = Column(Integer, primary_key=True, index=True)
    
    job_type = Column(String(100), nullable=False)
    
    company_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    status = Column(SQLEnum(AutomationJobStatus), default=AutomationJobStatus.PENDING)
    
    configuration = Column(JSON)
    
    target_environment = Column(String(100))
    target_region = Column(String(100))
    
    estimated_duration_minutes = Column(Integer)
    actual_duration_minutes = Column(Integer)
    
    resources_created = Column(JSON)
    
    cost_estimate = Column(Float)
    actual_cost = Column(Float)
    
    triggered_by = Column(Integer, ForeignKey("users.id"))
    triggered_by_ai = Column(Boolean, default=False)
    
    logs = Column(Text)
    
    error_message = Column(Text)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)


class InfrastructureResource(Base):
    __tablename__ = "infrastructure_resources"
    
    id = Column(Integer, primary_key=True, index=True)
    
    resource_type = Column(String(100), nullable=False)
    resource_name = Column(String(255), nullable=False)
    
    company_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    cloud_provider = Column(String(50))
    region = Column(String(100))
    
    resource_id = Column(String(255))
    
    configuration = Column(JSON)
    
    status = Column(String(50), default="active")
    
    monthly_cost = Column(Float)
    
    provisioned_by_job_id = Column(Integer, ForeignKey("devops_automation_jobs.id"))
    
    auto_scaling_enabled = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    last_modified = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SelfHealingEvent(Base):
    __tablename__ = "self_healing_events"
    
    id = Column(Integer, primary_key=True, index=True)
    
    incident_type = Column(String(100), nullable=False)
    
    resource_id = Column(Integer, ForeignKey("infrastructure_resources.id"))
    
    detected_at = Column(DateTime, nullable=False)
    
    severity = Column(String(50))
    
    symptoms = Column(JSON)
    
    root_cause_analysis = Column(Text)
    
    healing_action_taken = Column(Text, nullable=False)
    
    healing_status = Column(String(50), default="in_progress")
    
    resolved_at = Column(DateTime)
    resolution_time_seconds = Column(Integer)
    
    ai_confidence_score = Column(Float)
    
    manual_intervention_required = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class CostOptimizationRecommendation(Base):
    __tablename__ = "cost_optimization_recommendations"
    
    id = Column(Integer, primary_key=True, index=True)
    
    company_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    resource_id = Column(Integer, ForeignKey("infrastructure_resources.id"))
    
    recommendation_type = Column(String(100), nullable=False)
    
    current_cost_monthly = Column(Float, nullable=False)
    projected_cost_monthly = Column(Float, nullable=False)
    
    savings_monthly = Column(Float, nullable=False)
    savings_percentage = Column(Float)
    
    recommendation_details = Column(Text, nullable=False)
    
    action_required = Column(Text)
    
    priority = Column(String(50), default="medium")
    
    status = Column(String(50), default="pending")
    
    implemented_at = Column(DateTime)
    actual_savings_monthly = Column(Float)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class DeploymentPipeline(Base):
    __tablename__ = "deployment_pipelines"
    
    id = Column(Integer, primary_key=True, index=True)
    
    pipeline_name = Column(String(255), nullable=False)
    
    company_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    repository_url = Column(String(1000))
    branch = Column(String(255))
    
    pipeline_config = Column(JSON)
    
    stages = Column(JSON)
    
    auto_deploy = Column(Boolean, default=False)
    
    last_deployment_id = Column(Integer)
    last_deployment_status = Column(String(50))
    
    success_rate = Column(Float)
    average_duration_minutes = Column(Float)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class DeploymentExecution(Base):
    __tablename__ = "deployment_executions"
    
    id = Column(Integer, primary_key=True, index=True)
    
    pipeline_id = Column(Integer, ForeignKey("deployment_pipelines.id"), nullable=False)
    
    deployment_number = Column(String(50))
    
    commit_hash = Column(String(255))
    commit_message = Column(Text)
    
    triggered_by = Column(Integer, ForeignKey("users.id"))
    triggered_by_ai = Column(Boolean, default=False)
    
    environment = Column(String(100))
    
    status = Column(String(50), default="pending")
    
    stages_completed = Column(JSON)
    
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    duration_seconds = Column(Integer)
    
    logs_url = Column(String(1000))
    
    rollback_executed = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)
