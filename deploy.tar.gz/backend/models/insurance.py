"""
Insurance Models
Bug Bounty Insurance and related models
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text, JSON, ForeignKey, Enum as SQLEnum
from datetime import datetime
from enum import Enum

from core.database import Base


class InsurancePolicyStatus(str, Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    PENDING = "pending"


class InsuranceClaimStatus(str, Enum):
    SUBMITTED = "submitted"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    PAID = "paid"


class InsurancePolicy(Base):
    __tablename__ = "insurance_policies"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    policy_number = Column(String(50), unique=True, index=True, nullable=False)
    
    coverage_amount = Column(Float, nullable=False)
    premium_amount = Column(Float, nullable=False)
    
    policy_type = Column(String(100), default="bug_bounty_insurance")
    
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)
    
    status = Column(SQLEnum(InsurancePolicyStatus), default=InsurancePolicyStatus.PENDING)
    
    covered_assets = Column(JSON)
    
    pre_audit_score = Column(Float)
    risk_level = Column(String(50))
    
    terms_conditions = Column(Text)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class InsuranceClaim(Base):
    __tablename__ = "insurance_claims"
    
    id = Column(Integer, primary_key=True, index=True)
    policy_id = Column(Integer, ForeignKey("insurance_policies.id"), nullable=False)
    
    claim_number = Column(String(50), unique=True, index=True, nullable=False)
    
    bug_id = Column(Integer, ForeignKey("bugs.id"))
    
    claim_amount = Column(Float, nullable=False)
    approved_amount = Column(Float)
    
    status = Column(SQLEnum(InsuranceClaimStatus), default=InsuranceClaimStatus.SUBMITTED)
    
    incident_description = Column(Text, nullable=False)
    incident_date = Column(DateTime, nullable=False)
    
    supporting_documents = Column(JSON)
    
    reviewer_notes = Column(Text)
    reviewed_by = Column(Integer, ForeignKey("users.id"))
    reviewed_at = Column(DateTime)
    
    payment_date = Column(DateTime)
    payment_reference = Column(String(255))
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class InsurancePremiumPayment(Base):
    __tablename__ = "insurance_premium_payments"
    
    id = Column(Integer, primary_key=True, index=True)
    policy_id = Column(Integer, ForeignKey("insurance_policies.id"), nullable=False)
    
    payment_amount = Column(Float, nullable=False)
    payment_date = Column(DateTime, nullable=False)
    
    payment_method = Column(String(50))
    payment_reference = Column(String(255))
    
    billing_period_start = Column(DateTime)
    billing_period_end = Column(DateTime)
    
    status = Column(String(50), default="completed")
    
    created_at = Column(DateTime, default=datetime.utcnow)
