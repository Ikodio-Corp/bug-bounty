"""
Bug and vulnerability models - Core discovery system
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, Text, Enum as SQLEnum, ForeignKey, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

from core.database import Base


class BugSeverity(str, enum.Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class BugStatus(str, enum.Enum):
    DISCOVERED = "discovered"
    VALIDATING = "validating"
    VALIDATED = "validated"
    REPORTED = "reported"
    TRIAGED = "triaged"
    FIXED = "fixed"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    DUPLICATE = "duplicate"
    PAID = "paid"


class BugType(str, enum.Enum):
    SQL_INJECTION = "sql_injection"
    XSS = "xss"
    CSRF = "csrf"
    SSRF = "ssrf"
    XXE = "xxe"
    IDOR = "idor"
    AUTH_BYPASS = "auth_bypass"
    BUSINESS_LOGIC = "business_logic"
    RCE = "rce"
    LFI = "lfi"
    RFI = "rfi"
    DESERIALIZATION = "deserialization"
    API_SECURITY = "api_security"
    GRAPHQL = "graphql"
    OAUTH = "oauth"
    JWT = "jwt"
    CLOUD_MISCONFIGURATION = "cloud_misconfiguration"
    CONTAINER_ESCAPE = "container_escape"
    OTHER = "other"


class Bug(Base):
    __tablename__ = "bugs"
    
    id = Column(Integer, primary_key=True, index=True)
    hunter_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    scan_id = Column(Integer, ForeignKey("scans.id"))
    
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=False)
    
    bug_type = Column(SQLEnum(BugType), nullable=False)
    severity = Column(SQLEnum(BugSeverity), nullable=False)
    status = Column(SQLEnum(BugStatus), default=BugStatus.DISCOVERED, nullable=False)
    
    cvss_score = Column(Float)
    cwe_id = Column(String(50))
    
    target_url = Column(String(1000), nullable=False)
    target_domain = Column(String(255), nullable=False, index=True)
    endpoint = Column(String(1000))
    parameter = Column(String(255))
    
    steps_to_reproduce = Column(Text)
    proof_of_concept = Column(Text)
    impact = Column(Text)
    remediation = Column(Text)
    
    exploit_code = Column(Text)
    payload = Column(Text)
    
    screenshots = Column(JSON)
    video_url = Column(String(500))
    attachments = Column(JSON)
    
    platform_name = Column(String(100))
    platform_program_id = Column(String(255))
    platform_report_id = Column(String(255))
    
    is_chain = Column(Boolean, default=False)
    chain_bugs = Column(JSON)
    chain_description = Column(Text)
    
    discovery_time_seconds = Column(Integer)
    ai_generated = Column(Boolean, default=False)
    ai_confidence = Column(Float)
    
    bounty_amount = Column(Float, default=0.0)
    bounty_currency = Column(String(10), default="USD")
    
    private_sale = Column(Boolean, default=False)
    private_sale_amount = Column(Float)
    
    reported_at = Column(DateTime)
    accepted_at = Column(DateTime)
    fixed_at = Column(DateTime)
    paid_at = Column(DateTime)
    
    is_public = Column(Boolean, default=False)
    disclosure_date = Column(DateTime)
    
    tags = Column(JSON)
    bug_metadata = Column(JSON)
    
    # Validation workflow fields
    reviewer_id = Column(Integer, ForeignKey("users.id"))
    validated = Column(Boolean, default=False)
    paid_out = Column(Boolean, default=False)
    rejection_reason = Column(Text)
    validation_submitted_at = Column(DateTime)
    validation_assigned_at = Column(DateTime)
    validated_at = Column(DateTime)
    rejected_at = Column(DateTime)
    validation_comments = Column(Text)
    appeal_reason = Column(Text)
    appeal_submitted_at = Column(DateTime)
    
    # Duplicate detection fields
    duplicate_of_id = Column(Integer, ForeignKey("bugs.id"))
    duplicate_marked_at = Column(DateTime)
    duplicate_reason = Column(Text)
    
    # Issue tracking integration fields
    jira_issue_key = Column(String(255))
    jira_issue_id = Column(String(255))
    synced_to_jira_at = Column(DateTime)
    linear_issue_id = Column(String(255))
    linear_issue_identifier = Column(String(255))
    synced_to_linear_at = Column(DateTime)
    asana_task_id = Column(String(255))
    synced_to_asana_at = Column(DateTime)
    monday_item_id = Column(String(255))
    synced_to_monday_at = Column(DateTime)
    
    # Cloud provider fields
    cloud_provider = Column(String(50))
    cloud_finding_id = Column(String(255))
    cloud_finding_arn = Column(String(500))
    imported_at = Column(DateTime)
    exported_at = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    hunter = relationship("User", back_populates="bugs")
    scan = relationship("Scan", back_populates="bugs")
    fix_offers = relationship("FixOffer", back_populates="bug")


class Scan(Base):
    __tablename__ = "scans"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    target_url = Column(String(1000), nullable=False)
    target_domain = Column(String(255), nullable=False, index=True)
    
    scan_type = Column(String(50), default="full")
    status = Column(String(50), default="pending")
    
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    duration_seconds = Column(Integer)
    
    agents_used = Column(Integer)
    endpoints_tested = Column(Integer)
    vulnerabilities_found = Column(Integer)
    
    discovery_phase_time = Column(Integer)
    validation_phase_time = Column(Integer)
    reporting_phase_time = Column(Integer)
    
    reconnaissance_data = Column(JSON)
    tech_stack = Column(JSON)
    
    success = Column(Boolean, default=False)
    error_message = Column(Text)
    
    scan_metadata = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", back_populates="scans")
    bugs = relationship("Bug", back_populates="scan")


class ExploitChain(Base):
    __tablename__ = "exploit_chains"
    
    id = Column(Integer, primary_key=True, index=True)
    
    name = Column(String(500), nullable=False)
    description = Column(Text)
    
    bug_ids = Column(JSON, nullable=False)
    
    combined_severity = Column(SQLEnum(BugSeverity), nullable=False)
    combined_cvss = Column(Float)
    
    chain_logic = Column(Text)
    execution_steps = Column(JSON)
    
    impact = Column(Text)
    bounty_potential = Column(Float)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class VulnerabilityPattern(Base):
    __tablename__ = "vulnerability_patterns"
    
    id = Column(Integer, primary_key=True, index=True)
    
    pattern_name = Column(String(255), nullable=False)
    pattern_type = Column(SQLEnum(BugType), nullable=False)
    
    tech_stack = Column(JSON)
    framework = Column(String(100))
    version_range = Column(String(100))
    
    pattern_signature = Column(Text)
    detection_rules = Column(JSON)
    
    success_rate = Column(Float)
    false_positive_rate = Column(Float)
    
    fixes_applied = Column(Integer, default=0)
    fix_pattern = Column(Text)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
