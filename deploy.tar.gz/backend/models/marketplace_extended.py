"""
Bug Marketplace Models
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text, JSON, ForeignKey, Enum as SQLEnum
from datetime import datetime
from enum import Enum

from core.database import Base


class MarketplaceListingStatus(str, Enum):
    ACTIVE = "active"
    SOLD = "sold"
    CANCELLED = "cancelled"
    PENDING_VERIFICATION = "pending_verification"


class BugMarketplaceListing(Base):
    __tablename__ = "bug_marketplace_listings"
    
    id = Column(Integer, primary_key=True, index=True)
    bug_id = Column(Integer, ForeignKey("bugs.id"), nullable=False)
    seller_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    listing_price = Column(Float, nullable=False)
    
    instant_payment_percentage = Column(Float, default=80.0)
    
    original_bounty_amount = Column(Float)
    
    status = Column(SQLEnum(MarketplaceListingStatus), default=MarketplaceListingStatus.PENDING_VERIFICATION)
    
    verification_status = Column(String(50))
    verified_at = Column(DateTime)
    
    listing_type = Column(String(50), default="bug_rights")
    
    description = Column(Text)
    
    listed_at = Column(DateTime, default=datetime.utcnow)
    sold_at = Column(DateTime)
    
    views_count = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class BugMarketplaceTrade(Base):
    __tablename__ = "bug_marketplace_trades"
    
    id = Column(Integer, primary_key=True, index=True)
    listing_id = Column(Integer, ForeignKey("bug_marketplace_listings.id"), nullable=False)
    
    buyer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    seller_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    trade_price = Column(Float, nullable=False)
    
    platform_fee = Column(Float)
    seller_receives = Column(Float)
    
    trade_status = Column(String(50), default="pending")
    
    payment_method = Column(String(50))
    payment_reference = Column(String(255))
    
    escrow_released = Column(Boolean, default=False)
    escrow_released_at = Column(DateTime)
    
    traded_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class BugFuture(Base):
    __tablename__ = "bug_futures_extended"
    
    id = Column(Integer, primary_key=True, index=True)
    
    contract_name = Column(String(255), nullable=False)
    
    target_company = Column(String(255))
    target_technology = Column(String(255))
    vulnerability_type = Column(String(100))
    
    contract_price = Column(Float, nullable=False)
    
    payout_condition = Column(Text)
    
    expiration_date = Column(DateTime, nullable=False)
    
    status = Column(String(50), default="active")
    
    creator_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    total_contracts_issued = Column(Integer, default=0)
    total_contracts_traded = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class BugFuturePosition(Base):
    __tablename__ = "bug_future_positions"
    
    id = Column(Integer, primary_key=True, index=True)
    future_id = Column(Integer, ForeignKey("bug_futures_extended.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    position_type = Column(String(10), nullable=False)
    
    quantity = Column(Integer, nullable=False)
    entry_price = Column(Float, nullable=False)
    
    current_value = Column(Float)
    unrealized_pnl = Column(Float)
    
    status = Column(String(50), default="open")
    
    opened_at = Column(DateTime, default=datetime.utcnow)
    closed_at = Column(DateTime)
    
    realized_pnl = Column(Float)
