"""
Community models - Guild, University, Social features
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, Text, Enum as SQLEnum, ForeignKey, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

from core.database import Base


class GuildMembershipTier(str, enum.Enum):
    APPRENTICE = "apprentice"
    JOURNEYMAN = "journeyman"
    MASTER = "master"
    GRANDMASTER = "grandmaster"


class GuildMembership(Base):
    __tablename__ = "guild_memberships"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    tier = Column(SQLEnum(GuildMembershipTier), default=GuildMembershipTier.APPRENTICE, nullable=False)
    
    total_earnings = Column(Float, default=0.0)
    annual_dues = Column(Float, nullable=False)
    dues_paid = Column(Boolean, default=False)
    
    voting_power = Column(Integer, default=1)
    
    joined_at = Column(DateTime, nullable=False)
    last_payment_date = Column(DateTime)
    next_payment_date = Column(DateTime)
    
    benefits = Column(JSON)
    
    strikes = Column(Integer, default=0)
    warnings = Column(Integer, default=0)
    
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", back_populates="guild_memberships")


class GuildProposal(Base):
    __tablename__ = "guild_proposals"
    
    id = Column(Integer, primary_key=True, index=True)
    proposer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=False)
    
    proposal_type = Column(String(50), nullable=False)
    
    target_platform = Column(String(100))
    target_company = Column(String(255))
    
    action_requested = Column(Text)
    
    votes_for = Column(Integer, default=0)
    votes_against = Column(Integer, default=0)
    votes_abstain = Column(Integer, default=0)
    
    voting_threshold = Column(Float, default=0.75)
    
    status = Column(String(50), default="voting")
    
    voting_starts = Column(DateTime, nullable=False)
    voting_ends = Column(DateTime, nullable=False)
    
    result = Column(String(50))
    executed = Column(Boolean, default=False)
    executed_at = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class UniversityPartnership(Base):
    __tablename__ = "university_partnerships"
    
    id = Column(Integer, primary_key=True, index=True)
    
    university_name = Column(String(255), nullable=False, unique=True)
    university_code = Column(String(50), nullable=False, unique=True)
    
    country = Column(String(100))
    city = Column(String(100))
    
    contact_name = Column(String(255))
    contact_email = Column(String(255))
    contact_phone = Column(String(50))
    
    program_start_date = Column(DateTime)
    program_status = Column(String(50), default="active")
    
    annual_license_fee = Column(Float, nullable=False)
    student_platform_fee = Column(Float)
    
    enrolled_students = Column(Integer, default=0)
    graduated_students = Column(Integer, default=0)
    
    curriculum_version = Column(String(50))
    
    features_enabled = Column(JSON)
    
    total_bugs_found = Column(Integer, default=0)
    total_bounties_earned = Column(Float, default=0.0)
    
    placement_rate = Column(Float)
    avg_starting_salary = Column(Float)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Student(Base):
    __tablename__ = "students"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, unique=True)
    university_id = Column(Integer, ForeignKey("university_partnerships.id"), nullable=False)
    
    student_id_number = Column(String(100), nullable=False)
    
    enrollment_date = Column(DateTime, nullable=False)
    expected_graduation = Column(DateTime)
    graduation_date = Column(DateTime)
    
    year = Column(Integer)
    semester = Column(Integer)
    
    gpa = Column(Float)
    
    bugs_found = Column(Integer, default=0)
    bugs_required = Column(Integer)
    
    courses_completed = Column(JSON)
    current_courses = Column(JSON)
    
    certification_level = Column(String(50))
    certifications = Column(JSON)
    
    portfolio_url = Column(String(500))
    
    job_placement = Column(Boolean, default=False)
    employer = Column(String(255))
    starting_salary = Column(Float)
    
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SocialConnection(Base):
    __tablename__ = "social_connections"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    connected_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    connection_type = Column(String(50), default="follow")
    
    is_mutual = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class Post(Base):
    __tablename__ = "posts"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    content = Column(Text, nullable=False)
    post_type = Column(String(50), default="text")
    
    bug_id = Column(Integer, ForeignKey("bugs.id"))
    
    media_urls = Column(JSON)
    
    likes_count = Column(Integer, default=0)
    comments_count = Column(Integer, default=0)
    shares_count = Column(Integer, default=0)
    
    is_public = Column(Boolean, default=True)
    
    hashtags = Column(JSON)
    mentions = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Comment(Base):
    __tablename__ = "comments"
    
    id = Column(Integer, primary_key=True, index=True)
    post_id = Column(Integer, ForeignKey("posts.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    content = Column(Text, nullable=False)
    
    parent_comment_id = Column(Integer, ForeignKey("comments.id"))
    
    likes_count = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class Course(Base):
    __tablename__ = "courses"
    
    id = Column(Integer, primary_key=True, index=True)
    instructor_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    title = Column(String(500), nullable=False)
    description = Column(Text)
    
    category = Column(String(100))
    difficulty = Column(String(50))
    
    price = Column(Float, nullable=False)
    
    curriculum = Column(JSON)
    
    enrolled_count = Column(Integer, default=0)
    completed_count = Column(Integer, default=0)
    
    rating = Column(Float)
    reviews_count = Column(Integer, default=0)
    
    video_urls = Column(JSON)
    resources = Column(JSON)
    
    is_published = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class CreatorSubscription(Base):
    __tablename__ = "creator_subscriptions"
    
    id = Column(Integer, primary_key=True, index=True)
    creator_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    subscriber_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    tier = Column(String(50), nullable=False)
    
    monthly_price = Column(Float, nullable=False)
    
    benefits = Column(JSON)
    
    status = Column(String(50), default="active")
    
    started_at = Column(DateTime, nullable=False)
    next_billing_date = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)
