"""
Transaction Model - Financial transactions and payment tracking
"""

from sqlalchemy import Column, Integer, String, DateTime, Float, Text, JSON, ForeignKey, Boolean, Numeric, Index
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from decimal import Decimal

from core.database import Base


class TransactionType(str, enum.Enum):
    """Types of financial transactions"""
    # Bounty payments
    BOUNTY_REWARD = "bounty_reward"
    BOUNTY_ESCROW = "bounty_escrow"
    BOUNTY_REFUND = "bounty_refund"
    
    # Subscription payments
    SUBSCRIPTION = "subscription"
    SUBSCRIPTION_RENEWAL = "subscription_renewal"
    SUBSCRIPTION_UPGRADE = "subscription_upgrade"
    SUBSCRIPTION_REFUND = "subscription_refund"
    
    # Marketplace transactions
    PRODUCT_PURCHASE = "product_purchase"
    PRODUCT_SALE = "product_sale"
    MARKETPLACE_FEE = "marketplace_fee"
    
    # Platform fees
    PLATFORM_FEE = "platform_fee"
    SERVICE_FEE = "service_fee"
    TRANSACTION_FEE = "transaction_fee"
    
    # Payouts
    PAYOUT = "payout"
    PAYOUT_REVERSAL = "payout_reversal"
    
    # Credits and tokens
    CREDIT_PURCHASE = "credit_purchase"
    CREDIT_USAGE = "credit_usage"
    CREDIT_REFUND = "credit_refund"
    TOKEN_PURCHASE = "token_purchase"
    TOKEN_TRANSFER = "token_transfer"
    
    # NFT transactions
    NFT_MINT = "nft_mint"
    NFT_SALE = "nft_sale"
    NFT_ROYALTY = "nft_royalty"
    
    # Staking and DeFi
    STAKE_DEPOSIT = "stake_deposit"
    STAKE_WITHDRAWAL = "stake_withdrawal"
    STAKE_REWARD = "stake_reward"
    
    # Other
    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"
    TRANSFER = "transfer"
    ADJUSTMENT = "adjustment"
    CHARGEBACK = "chargeback"


class TransactionStatus(str, enum.Enum):
    """Transaction status"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"
    DISPUTED = "disputed"
    ON_HOLD = "on_hold"


class PaymentMethod(str, enum.Enum):
    """Payment methods"""
    CREDIT_CARD = "credit_card"
    DEBIT_CARD = "debit_card"
    BANK_TRANSFER = "bank_transfer"
    PAYPAL = "paypal"
    STRIPE = "stripe"
    CRYPTOCURRENCY = "cryptocurrency"
    ETHEREUM = "ethereum"
    BITCOIN = "bitcoin"
    USDC = "usdc"
    PLATFORM_CREDIT = "platform_credit"
    BALANCE = "balance"


class Currency(str, enum.Enum):
    """Supported currencies"""
    USD = "usd"
    EUR = "eur"
    GBP = "gbp"
    ETH = "eth"
    BTC = "btc"
    USDC = "usdc"
    MATIC = "matic"


class Transaction(Base):
    """Financial transaction tracking"""
    __tablename__ = "transactions"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Transaction identification
    transaction_id = Column(String(100), unique=True, nullable=False, index=True)  # our internal ID
    external_id = Column(String(255), index=True)  # payment processor ID (Stripe, PayPal, etc.)
    reference = Column(String(100), index=True)  # human-readable reference
    
    # Transaction type and status
    type = Column(String(50), nullable=False, index=True)
    status = Column(String(20), default=TransactionStatus.PENDING, nullable=False, index=True)
    
    # Parties involved
    from_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    to_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    
    # Amount details
    amount = Column(Numeric(precision=18, scale=8), nullable=False)  # supports crypto decimals
    currency = Column(String(10), default=Currency.USD, nullable=False)
    fee = Column(Numeric(precision=18, scale=8), default=Decimal('0'))
    net_amount = Column(Numeric(precision=18, scale=8))  # amount - fee
    
    # Exchange rate for crypto transactions
    exchange_rate = Column(Numeric(precision=18, scale=8))
    usd_equivalent = Column(Numeric(precision=18, scale=2))
    
    # Payment details
    payment_method = Column(String(50), nullable=False)
    payment_processor = Column(String(50))  # stripe, paypal, coinbase, etc.
    
    # Related entities
    related_type = Column(String(50))  # bug, scan, subscription, product, etc.
    related_id = Column(Integer)
    
    # Description and metadata
    description = Column(Text)
    notes = Column(Text)
    transaction_metadata = Column(JSON)  # flexible data storage (renamed from metadata)
    
    # Payment processor response
    processor_response = Column(JSON)
    processor_fee = Column(Numeric(precision=18, scale=2))
    
    # Blockchain details (for crypto transactions)
    blockchain = Column(String(50))  # ethereum, bitcoin, polygon, etc.
    transaction_hash = Column(String(255), index=True)
    wallet_address_from = Column(String(255))
    wallet_address_to = Column(String(255))
    block_number = Column(Integer)
    gas_fee = Column(Numeric(precision=18, scale=8))
    
    # Timing
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    processed_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    
    # Refund information
    is_refunded = Column(Boolean, default=False)
    refunded_at = Column(DateTime, nullable=True)
    refund_reason = Column(Text)
    refund_transaction_id = Column(Integer, ForeignKey("transactions.id"))
    
    # Dispute information
    is_disputed = Column(Boolean, default=False)
    disputed_at = Column(DateTime, nullable=True)
    dispute_reason = Column(Text)
    dispute_resolved_at = Column(DateTime, nullable=True)
    
    # Risk and fraud detection
    risk_score = Column(Float, default=0.0)
    is_flagged = Column(Boolean, default=False)
    flag_reason = Column(Text)
    
    # Relationships
    from_user = relationship("User", foreign_keys=[from_user_id], back_populates="transactions_sent")
    to_user = relationship("User", foreign_keys=[to_user_id], back_populates="transactions_received")
    refund_transaction = relationship("Transaction", remote_side=[id])
    
    # Indexes
    __table_args__ = (
        Index('idx_transaction_user_type', 'from_user_id', 'type'),
        Index('idx_transaction_user_status', 'to_user_id', 'status'),
        Index('idx_transaction_type_date', 'type', 'created_at'),
        Index('idx_transaction_status_date', 'status', 'created_at'),
        Index('idx_transaction_related', 'related_type', 'related_id'),
    )
    
    def __repr__(self):
        return f"<Transaction(id={self.transaction_id}, type={self.type}, amount={self.amount} {self.currency}, status={self.status})>"


class Balance(Base):
    """User balance tracking"""
    __tablename__ = "balances"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Balances by currency
    usd_balance = Column(Numeric(precision=18, scale=2), default=Decimal('0'), nullable=False)
    eth_balance = Column(Numeric(precision=18, scale=8), default=Decimal('0'), nullable=False)
    btc_balance = Column(Numeric(precision=18, scale=8), default=Decimal('0'), nullable=False)
    usdc_balance = Column(Numeric(precision=18, scale=8), default=Decimal('0'), nullable=False)
    
    # Platform credits
    credits = Column(Integer, default=0, nullable=False)
    bonus_credits = Column(Integer, default=0, nullable=False)
    
    # Locked amounts (in escrow, pending, etc.)
    locked_usd = Column(Numeric(precision=18, scale=2), default=Decimal('0'), nullable=False)
    locked_eth = Column(Numeric(precision=18, scale=8), default=Decimal('0'), nullable=False)
    
    # Lifetime stats
    total_earned = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    total_spent = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    total_withdrawn = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    
    # Timing
    last_transaction_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="balance")
    
    def __repr__(self):
        return f"<Balance(user={self.user_id}, usd={self.usd_balance}, credits={self.credits})>"


class PayoutMethod(Base):
    """User payout method configuration"""
    __tablename__ = "payout_methods"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    method_type = Column(String(50), nullable=False)  # bank_transfer, paypal, crypto, etc.
    is_default = Column(Boolean, default=False)
    is_verified = Column(Boolean, default=False)
    
    # Bank details
    bank_name = Column(String(255))
    account_number = Column(String(255))  # encrypted
    routing_number = Column(String(50))
    swift_code = Column(String(50))
    iban = Column(String(100))
    
    # PayPal
    paypal_email = Column(String(255))
    
    # Crypto
    wallet_address = Column(String(255))
    wallet_type = Column(String(50))  # ethereum, bitcoin, etc.
    
    # Metadata
    details = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="payout_methods")
    
    def __repr__(self):
        return f"<PayoutMethod(user={self.user_id}, type={self.method_type}, default={self.is_default})>"
