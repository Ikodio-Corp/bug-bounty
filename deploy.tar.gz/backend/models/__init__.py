"""
Models package - All database models
"""

from models.user import User, UserProfile, Subscription, UserRole, SubscriptionTier
from models.bug import (
    Bug, Scan, ExploitChain, VulnerabilityPattern,
    BugType, BugSeverity, BugStatus
)
from models.marketplace import (
    FixOffer, MarketplaceListing, BugNFT, Payment,
    BugFuture, SubscriptionBox, FixStatus, PaymentStatus
)
from models.intelligence import (
    SecurityScore, VulnerabilityForecast, ExploitDatabase,
    IntelligenceReport, BugDerivative, BugIndexFund
)
from models.community import (
    GuildMembership, GuildProposal, UniversityPartnership,
    Student, SocialConnection, Post, Comment,
    Course, CreatorSubscription, GuildMembershipTier
)
from models.advanced import (
    QuantumJob, SatelliteIntelligence, AGIResearchLog,
    GeopoliticalContract, SanctionTarget, ESGScore,
    DAOGovernance, BCISecurityAudit
)

# New core models
from models.audit_log import AuditLog, AuditLogRetention, AuditEventType, AuditSeverity
from models.notification import (
    Notification, NotificationPreference, NotificationTemplate,
    NotificationType, NotificationChannel, NotificationPriority
)
from models.transaction import (
    Transaction, Balance, PayoutMethod,
    TransactionType, TransactionStatus, PaymentMethod, Currency
)
from models.futures import (
    FuturesContract, FuturesPosition, FuturesOrder, FuturesPredictionMarket,
    FuturesContractType, PositionType, OrderType
)

# Revolutionary features
from models.insurance import (
    InsurancePolicy, InsuranceClaim, InsurancePremiumPayment,
    InsurancePolicyStatus, InsuranceClaimStatus
)
from models.security_score import (
    SecurityScore as SecurityCreditScore, SecurityScoreHistory,
    SecurityScoreReport, SecurityScoreSubscription
)
from models.marketplace_extended import (
    BugMarketplaceListing, BugMarketplaceTrade,
    BugFuture as BugFutureContract, BugFuturePosition,
    MarketplaceListingStatus
)
from models.dao import (
    DAOGovernance as DAOGovernanceExtended, DAOProposal, DAOVote,
    DAOToken, DAOTreasuryTransaction, ProposalStatus
)
from models.devops import (
    DevOpsAutomationJob, InfrastructureResource, SelfHealingEvent,
    CostOptimizationRecommendation, DeploymentPipeline, DeploymentExecution,
    AutomationJobStatus
)
from models.certificate import Certificate
from models.webhook import Webhook, WebhookDelivery
from models.report import Report

__all__ = [
    # User models
    "User", "UserProfile", "Subscription", "UserRole", "SubscriptionTier",
    
    # Bug models
    "Bug", "Scan", "ExploitChain", "VulnerabilityPattern",
    "BugType", "BugSeverity", "BugStatus",
    
    # Marketplace models
    "FixOffer", "MarketplaceListing", "BugNFT", "Payment",
    "BugFuture", "SubscriptionBox", "FixStatus", "PaymentStatus",
    
    # Intelligence models
    "SecurityScore", "VulnerabilityForecast", "ExploitDatabase",
    "IntelligenceReport", "BugDerivative", "BugIndexFund",
    
    # Community models
    "GuildMembership", "GuildProposal", "UniversityPartnership",
    "Student", "SocialConnection", "Post", "Comment",
    "Course", "CreatorSubscription", "GuildMembershipTier",
    
    # Advanced models
    "QuantumJob", "SatelliteIntelligence", "AGIResearchLog",
    "GeopoliticalContract", "SanctionTarget", "ESGScore",
    "DAOGovernance", "BCISecurityAudit",
    
    # Revolutionary Insurance
    "InsurancePolicy", "InsuranceClaim", "InsurancePremiumPayment",
    "InsurancePolicyStatus", "InsuranceClaimStatus",
    
    # Revolutionary Security Score
    "SecurityCreditScore", "SecurityScoreHistory",
    "SecurityScoreReport", "SecurityScoreSubscription",
    
    # Revolutionary Marketplace Extended
    "BugMarketplaceListing", "BugMarketplaceTrade",
    "BugFutureContract", "BugFuturePosition", "MarketplaceListingStatus",
    
    # Revolutionary DAO
    "DAOGovernanceExtended", "DAOProposal", "DAOVote",
    "DAOToken", "DAOTreasuryTransaction", "ProposalStatus",
    
    # Revolutionary DevOps
    "DevOpsAutomationJob", "InfrastructureResource", "SelfHealingEvent",
    "CostOptimizationRecommendation", "DeploymentPipeline", "DeploymentExecution",
    "AutomationJobStatus",
    
    # Certificate, Webhook, Report models
    "Certificate", "Webhook", "WebhookDelivery", "Report",
]
