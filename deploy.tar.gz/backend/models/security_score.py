"""
Security Credit Score Models
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Text, JSON, ForeignKey
from datetime import datetime

from core.database import Base


class SecurityScore(Base):
    __tablename__ = "security_credit_scores"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    score = Column(Integer, nullable=False)
    
    grade = Column(String(10))
    
    technical_security_score = Column(Float)
    process_maturity_score = Column(Float)
    compliance_score = Column(Float)
    historical_track_record_score = Column(Float)
    
    vulnerability_count = Column(Integer, default=0)
    critical_vulnerabilities = Column(Integer, default=0)
    high_vulnerabilities = Column(Integer, default=0)
    
    patch_velocity_days = Column(Float)
    
    incident_count = Column(Integer, default=0)
    breach_count = Column(Integer, default=0)
    
    certifications = Column(JSON)
    
    calculated_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    valid_until = Column(DateTime)
    
    report_url = Column(String(1000))
    
    created_at = Column(DateTime, default=datetime.utcnow)


class SecurityScoreHistory(Base):
    __tablename__ = "security_score_history"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    score = Column(Integer, nullable=False)
    
    change_from_previous = Column(Integer)
    
    factors_improved = Column(JSON)
    factors_degraded = Column(JSON)
    
    recorded_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class SecurityScoreReport(Base):
    __tablename__ = "security_score_reports"
    
    id = Column(Integer, primary_key=True, index=True)
    score_id = Column(Integer, ForeignKey("security_scores.id"), nullable=False)
    
    report_type = Column(String(50), nullable=False)
    
    detailed_analysis = Column(Text)
    
    recommendations = Column(JSON)
    
    executive_summary = Column(Text)
    technical_details = Column(JSON)
    
    generated_by = Column(Integer, ForeignKey("users.id"))
    generated_at = Column(DateTime, default=datetime.utcnow)
    
    purchased_by = Column(Integer, ForeignKey("users.id"))
    purchase_price = Column(Float)
    purchased_at = Column(DateTime)
    
    access_token = Column(String(255), unique=True)


class SecurityScoreSubscription(Base):
    __tablename__ = "security_score_subscriptions"
    
    id = Column(Integer, primary_key=True, index=True)
    subscriber_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    company_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    subscription_type = Column(String(50), nullable=False)
    
    monitoring_frequency = Column(String(50))
    
    alert_thresholds = Column(JSON)
    
    active = Column(Integer, default=1)
    
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)
