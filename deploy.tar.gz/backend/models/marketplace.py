"""
Marketplace models - Fix network, NFT, payments
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, Text, Enum as SQLEnum, ForeignKey, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

from core.database import Base
from models.bug import BugSeverity


class FixStatus(str, enum.Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    VERIFIED = "verified"
    REJECTED = "rejected"
    DISPUTED = "disputed"


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"


class FixOffer(Base):
    __tablename__ = "fix_offers"
    
    id = Column(Integer, primary_key=True, index=True)
    bug_id = Column(Integer, ForeignKey("bugs.id"), nullable=False)
    developer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    status = Column(SQLEnum(FixStatus), default=FixStatus.PENDING, nullable=False)
    
    estimated_hours = Column(Float, nullable=False)
    hourly_rate = Column(Float, nullable=False)
    total_cost = Column(Float, nullable=False)
    
    description = Column(Text)
    technical_approach = Column(Text)
    timeline = Column(String(255))
    
    pull_request_url = Column(String(500))
    commit_hash = Column(String(255))
    
    accepted_at = Column(DateTime)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    verified_at = Column(DateTime)
    
    rating = Column(Integer)
    review = Column(Text)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    bug = relationship("Bug", back_populates="fix_offers")


class MarketplaceListing(Base):
    __tablename__ = "marketplace_listings"
    
    id = Column(Integer, primary_key=True, index=True)
    bug_id = Column(Integer, ForeignKey("bugs.id"), nullable=False)
    seller_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    listing_type = Column(String(50), nullable=False)
    
    asking_price = Column(Float, nullable=False)
    currency = Column(String(10), default="USD")
    
    is_private = Column(Boolean, default=False)
    is_exclusive = Column(Boolean, default=False)
    
    description = Column(Text)
    terms = Column(Text)
    
    views = Column(Integer, default=0)
    interested_buyers = Column(JSON)
    
    status = Column(String(50), default="active")
    sold_at = Column(DateTime)
    buyer_id = Column(Integer)
    sale_price = Column(Float)
    
    platform_fee = Column(Float)
    seller_payout = Column(Float)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class BugNFT(Base):
    __tablename__ = "bug_nfts"
    
    id = Column(Integer, primary_key=True, index=True)
    bug_id = Column(Integer, ForeignKey("bugs.id"), nullable=False, unique=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    token_id = Column(String(255), unique=True, nullable=False)
    contract_address = Column(String(255), nullable=False)
    blockchain = Column(String(50), default="ethereum")
    
    metadata_uri = Column(String(500))
    nft_metadata = Column(JSON)
    
    mint_price = Column(Float)
    current_price = Column(Float)
    
    royalty_percentage = Column(Float, default=10.0)
    
    is_listed = Column(Boolean, default=False)
    listing_price = Column(Float)
    
    transaction_history = Column(JSON)
    
    minted_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Payment(Base):
    __tablename__ = "payments"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    payment_type = Column(String(50), nullable=False)
    status = Column(SQLEnum(PaymentStatus), default=PaymentStatus.PENDING, nullable=False)
    
    amount = Column(Float, nullable=False)
    currency = Column(String(10), default="USD")
    
    stripe_payment_id = Column(String(255))
    stripe_charge_id = Column(String(255))
    
    crypto_tx_hash = Column(String(255))
    crypto_wallet = Column(String(255))
    
    description = Column(Text)
    payment_metadata = Column(JSON)
    
    related_id = Column(Integer)
    related_type = Column(String(50))
    
    processed_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)


class BugFuture(Base):
    __tablename__ = "bug_futures_old"
    
    id = Column(Integer, primary_key=True, index=True)
    buyer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    target_company = Column(String(255), nullable=False)
    target_domain = Column(String(255), nullable=False)
    
    requested_severity = Column(SQLEnum(BugSeverity))
    requested_types = Column(JSON)
    
    budget = Column(Float, nullable=False)
    deadline = Column(DateTime, nullable=False)
    
    requirements = Column(Text)
    special_instructions = Column(Text)
    
    status = Column(String(50), default="open")
    
    assigned_hunter_id = Column(Integer)
    assigned_at = Column(DateTime)
    
    completed_at = Column(DateTime)
    bug_id = Column(Integer, ForeignKey("bugs.id"))
    
    created_at = Column(DateTime, default=datetime.utcnow)


class SubscriptionBox(Base):
    __tablename__ = "subscription_boxes"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    tier = Column(String(50), nullable=False)
    
    monthly_fee = Column(Float, nullable=False)
    bug_quota = Column(Integer, nullable=False)
    bugs_found = Column(Integer, default=0)
    
    guaranteed_severity = Column(SQLEnum(BugSeverity))
    
    domains = Column(JSON)
    scope = Column(JSON)
    
    status = Column(String(50), default="active")
    
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)
