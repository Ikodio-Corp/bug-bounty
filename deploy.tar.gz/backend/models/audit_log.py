"""
Audit Log Model - Track all system activities and security events
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, JSON, Boolean, Enum as SQLEnum, Index, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

from core.database import Base


class AuditEventType(str, enum.Enum):
    """Types of audit events"""
    # Authentication events
    LOGIN = "login"
    LOGOUT = "logout"
    LOGIN_FAILED = "login_failed"
    PASSWORD_CHANGE = "password_change"
    PASSWORD_RESET = "password_reset"
    MFA_ENABLED = "mfa_enabled"
    MFA_DISABLED = "mfa_disabled"
    
    # User management
    USER_CREATED = "user_created"
    USER_UPDATED = "user_updated"
    USER_DELETED = "user_deleted"
    USER_SUSPENDED = "user_suspended"
    USER_ACTIVATED = "user_activated"
    
    # Bug bounty events
    BUG_SUBMITTED = "bug_submitted"
    BUG_UPDATED = "bug_updated"
    BUG_VALIDATED = "bug_validated"
    BUG_REJECTED = "bug_rejected"
    BUG_PAID = "bug_paid"
    
    # Scan events
    SCAN_STARTED = "scan_started"
    SCAN_COMPLETED = "scan_completed"
    SCAN_FAILED = "scan_failed"
    
    # Payment events
    PAYMENT_INITIATED = "payment_initiated"
    PAYMENT_SUCCESS = "payment_success"
    PAYMENT_FAILED = "payment_failed"
    
    # Security events
    SUSPICIOUS_ACTIVITY = "suspicious_activity"
    RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"
    UNAUTHORIZED_ACCESS = "unauthorized_access"
    API_KEY_CREATED = "api_key_created"
    API_KEY_REVOKED = "api_key_revoked"
    
    # System events
    CONFIG_CHANGED = "config_changed"
    BACKUP_CREATED = "backup_created"
    BACKUP_RESTORED = "backup_restored"
    MAINTENANCE_MODE = "maintenance_mode"
    
    # Admin actions
    ADMIN_ACTION = "admin_action"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DATA_EXPORT = "data_export"
    DATA_DELETE = "data_delete"


class AuditSeverity(str, enum.Enum):
    """Severity levels for audit events"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class AuditLog(Base):
    """Comprehensive audit logging for compliance and security"""
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Event information
    event_type = Column(String(50), nullable=False, index=True)
    severity = Column(String(20), default=AuditSeverity.INFO, nullable=False, index=True)
    category = Column(String(50), index=True)  # auth, user, bug, scan, payment, security, system, admin
    
    # Actor information (who did it)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    username = Column(String(100), index=True)
    ip_address = Column(String(45))  # IPv6 compatible
    user_agent = Column(Text)
    
    # Target information (what was affected)
    target_type = Column(String(50))  # user, bug, scan, payment, etc.
    target_id = Column(Integer)
    target_name = Column(String(255))
    
    # Event details
    action = Column(String(255), nullable=False)
    description = Column(Text)
    changes = Column(JSON)  # before/after values for updates
    event_metadata = Column(JSON)  # additional context (renamed from metadata to avoid SQLAlchemy conflict)
    
    # Request information
    request_method = Column(String(10))  # GET, POST, PUT, DELETE, etc.
    request_path = Column(String(500))
    request_params = Column(JSON)
    response_status = Column(Integer)
    
    # Timing
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    duration_ms = Column(Integer)  # request duration in milliseconds
    
    # Compliance flags
    is_sensitive = Column(Boolean, default=False)  # PII or sensitive data involved
    requires_review = Column(Boolean, default=False)  # requires manual review
    reviewed_at = Column(DateTime, nullable=True)
    reviewed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    
    # Relationships
    user = relationship("User", foreign_keys=[user_id], back_populates="audit_logs")
    reviewer = relationship("User", foreign_keys=[reviewed_by])
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_audit_user_time', 'user_id', 'created_at'),
        Index('idx_audit_event_time', 'event_type', 'created_at'),
        Index('idx_audit_target', 'target_type', 'target_id'),
        Index('idx_audit_severity_time', 'severity', 'created_at'),
        Index('idx_audit_category_time', 'category', 'created_at'),
    )
    
    def __repr__(self):
        return f"<AuditLog(id={self.id}, event={self.event_type}, user={self.username}, time={self.created_at})>"


class AuditLogRetention(Base):
    """Audit log retention policy configuration"""
    __tablename__ = "audit_log_retention"
    
    id = Column(Integer, primary_key=True)
    event_type = Column(String(50), unique=True, nullable=False)
    retention_days = Column(Integer, default=365, nullable=False)
    archive_after_days = Column(Integer, default=90)
    delete_after_days = Column(Integer, default=365)
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<AuditLogRetention(event={self.event_type}, retention={self.retention_days}d)>"
