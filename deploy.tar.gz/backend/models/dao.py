"""
DAO Governance Models
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text, JSON, ForeignKey, Enum as SQLEnum
from datetime import datetime
from enum import Enum

from core.database import Base


class ProposalStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    PASSED = "passed"
    REJECTED = "rejected"
    EXECUTED = "executed"
    CANCELLED = "cancelled"


class DAOGovernance(Base):
    __tablename__ = "dao_governance_extended"
    
    id = Column(Integer, primary_key=True, index=True)
    
    dao_name = Column(String(255), nullable=False, default="IKOD DAO")
    
    total_token_supply = Column(Float, default=1000000000)
    circulating_supply = Column(Float, default=0)
    
    governance_token_symbol = Column(String(10), default="IKOD")
    
    treasury_balance = Column(Float, default=0)
    
    min_proposal_tokens = Column(Float, default=10000)
    
    voting_period_hours = Column(Integer, default=168)
    
    quorum_percentage = Column(Float, default=10.0)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class DAOProposal(Base):
    __tablename__ = "dao_proposals"
    
    id = Column(Integer, primary_key=True, index=True)
    
    proposal_number = Column(String(50), unique=True, index=True)
    
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=False)
    
    proposer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    proposal_type = Column(String(100))
    
    status = Column(SQLEnum(ProposalStatus), default=ProposalStatus.DRAFT)
    
    voting_starts_at = Column(DateTime)
    voting_ends_at = Column(DateTime)
    
    votes_for = Column(Float, default=0)
    votes_against = Column(Float, default=0)
    votes_abstain = Column(Float, default=0)
    
    total_voting_power = Column(Float)
    
    quorum_reached = Column(Boolean, default=False)
    
    execution_data = Column(JSON)
    executed_at = Column(DateTime)
    executed_by = Column(Integer, ForeignKey("users.id"))
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class DAOVote(Base):
    __tablename__ = "dao_votes"
    
    id = Column(Integer, primary_key=True, index=True)
    proposal_id = Column(Integer, ForeignKey("dao_proposals.id"), nullable=False)
    voter_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    vote_choice = Column(String(20), nullable=False)
    
    voting_power = Column(Float, nullable=False)
    
    reason = Column(Text)
    
    voted_at = Column(DateTime, default=datetime.utcnow)


class DAOToken(Base):
    __tablename__ = "dao_tokens"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    token_balance = Column(Float, default=0)
    
    staked_balance = Column(Float, default=0)
    
    earned_from_bug_bounties = Column(Float, default=0)
    earned_from_marketplace = Column(Float, default=0)
    earned_from_governance = Column(Float, default=0)
    
    voting_power = Column(Float, default=0)
    
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)


class DAOTreasuryTransaction(Base):
    __tablename__ = "dao_treasury_transactions"
    
    id = Column(Integer, primary_key=True, index=True)
    
    transaction_type = Column(String(50), nullable=False)
    
    amount = Column(Float, nullable=False)
    
    from_address = Column(String(255))
    to_address = Column(String(255))
    
    purpose = Column(Text)
    
    proposal_id = Column(Integer, ForeignKey("dao_proposals.id"))
    
    transaction_hash = Column(String(255))
    
    executed_at = Column(DateTime, default=datetime.utcnow)
