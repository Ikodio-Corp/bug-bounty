"""
Intelligence and analytics models - Data products
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, Text, JSON, ForeignKey
from datetime import datetime

from core.database import Base


class SecurityScore(Base):
    __tablename__ = "security_scores"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("users.id"))
    
    company_name = Column(String(255), nullable=False, index=True)
    domain = Column(String(255), nullable=False, unique=True, index=True)
    
    overall_score = Column(Float, nullable=False)
    vulnerability_score = Column(Float)
    fix_response_score = Column(Float)
    disclosure_score = Column(Float)
    
    total_bugs_found = Column(Integer, default=0)
    critical_bugs = Column(Integer, default=0)
    high_bugs = Column(Integer, default=0)
    medium_bugs = Column(Integer, default=0)
    low_bugs = Column(Integer, default=0)
    
    avg_fix_time_days = Column(Float)
    bugs_fixed = Column(Integer, default=0)
    bugs_unfixed = Column(Integer, default=0)
    
    last_bug_date = Column(DateTime)
    last_fix_date = Column(DateTime)
    
    tech_stack = Column(JSON)
    vulnerability_trends = Column(JSON)
    
    industry = Column(String(100))
    company_size = Column(String(50))
    
    historical_scores = Column(JSON)
    
    report_generated = Column(Boolean, default=False)
    report_url = Column(String(500))
    report_price = Column(Float)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class VulnerabilityForecast(Base):
    __tablename__ = "vulnerability_forecasts"
    
    id = Column(Integer, primary_key=True, index=True)
    
    forecast_period = Column(String(50), nullable=False)
    industry = Column(String(100))
    tech_stack = Column(String(100))
    
    predicted_vulnerability_count = Column(Integer)
    confidence_level = Column(Float)
    
    vulnerability_type_distribution = Column(JSON)
    severity_distribution = Column(JSON)
    
    trending_vulnerabilities = Column(JSON)
    emerging_patterns = Column(JSON)
    
    market_intelligence = Column(JSON)
    
    recommendations = Column(Text)
    
    data_points_analyzed = Column(Integer)
    model_accuracy = Column(Float)
    
    subscribers = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class ExploitDatabase(Base):
    __tablename__ = "exploit_database"
    
    id = Column(Integer, primary_key=True, index=True)
    
    exploit_name = Column(String(500), nullable=False)
    exploit_type = Column(String(100), nullable=False)
    
    target_tech = Column(String(255))
    target_version = Column(String(100))
    
    cve_id = Column(String(50))
    cvss_score = Column(Float)
    
    exploit_code = Column(Text)
    payload = Column(Text)
    
    discovery_method = Column(Text)
    exploitation_steps = Column(JSON)
    
    fix_pattern = Column(Text)
    fix_code = Column(Text)
    
    successful_exploits = Column(Integer, default=0)
    false_positives = Column(Integer, default=0)
    
    companies_affected = Column(JSON)
    
    is_public = Column(Boolean, default=False)
    disclosure_date = Column(DateTime)
    
    license_required = Column(Boolean, default=True)
    license_price = Column(Float)
    
    intel_metadata = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class IntelligenceReport(Base):
    __tablename__ = "intelligence_reports"
    
    id = Column(Integer, primary_key=True, index=True)
    
    report_type = Column(String(100), nullable=False)
    title = Column(String(500), nullable=False)
    
    target_company = Column(String(255))
    target_industry = Column(String(100))
    
    executive_summary = Column(Text)
    detailed_analysis = Column(Text)
    recommendations = Column(Text)
    
    security_score = Column(Float)
    risk_level = Column(String(50))
    
    vulnerabilities_analyzed = Column(Integer)
    data_sources = Column(JSON)
    
    charts = Column(JSON)
    tables = Column(JSON)
    
    buyer_id = Column(Integer, ForeignKey("users.id"))
    price = Column(Float)
    
    is_confidential = Column(Boolean, default=True)
    
    generated_at = Column(DateTime, nullable=False)
    purchased_at = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class BugDerivative(Base):
    __tablename__ = "bug_derivatives"
    
    id = Column(Integer, primary_key=True, index=True)
    
    derivative_type = Column(String(50), nullable=False)
    
    underlying_asset = Column(String(255), nullable=False)
    prediction = Column(Text, nullable=False)
    
    confidence_percentage = Column(Float, nullable=False)
    
    strike_condition = Column(Text)
    expiry_date = Column(DateTime, nullable=False)
    
    premium = Column(Float, nullable=False)
    payout = Column(Float, nullable=False)
    
    seller_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    buyer_id = Column(Integer, ForeignKey("users.id"))
    
    status = Column(String(50), default="active")
    
    outcome = Column(String(50))
    settled_at = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class BugIndexFund(Base):
    __tablename__ = "bug_index_funds"
    
    id = Column(Integer, primary_key=True, index=True)
    
    fund_name = Column(String(255), nullable=False, unique=True)
    fund_symbol = Column(String(10), nullable=False, unique=True)
    
    description = Column(Text)
    strategy = Column(Text)
    
    total_value = Column(Float, default=0.0)
    shares_outstanding = Column(Integer, default=0)
    nav_per_share = Column(Float)
    
    bug_portfolio = Column(JSON)
    industry_allocation = Column(JSON)
    severity_allocation = Column(JSON)
    
    ytd_return = Column(Float)
    inception_return = Column(Float)
    
    management_fee = Column(Float, default=2.0)
    performance_fee = Column(Float, default=20.0)
    
    minimum_investment = Column(Float)
    
    investors = Column(JSON)
    
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
