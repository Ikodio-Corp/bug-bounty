"""
Notification Model - Multi-channel notification system
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, JSON, ForeignKey, Boolean, Index
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

from core.database import Base


class NotificationType(str, enum.Enum):
    """Types of notifications"""
    # Bug bounty notifications
    BUG_SUBMITTED = "bug_submitted"
    BUG_VALIDATED = "bug_validated"
    BUG_REJECTED = "bug_rejected"
    BUG_COMMENT = "bug_comment"
    BUG_STATUS_CHANGED = "bug_status_changed"
    
    # Payment notifications
    PAYMENT_RECEIVED = "payment_received"
    PAYMENT_PENDING = "payment_pending"
    PAYMENT_FAILED = "payment_failed"
    PAYOUT_PROCESSED = "payout_processed"
    
    # Scan notifications
    SCAN_COMPLETED = "scan_completed"
    SCAN_FAILED = "scan_failed"
    VULNERABILITY_FOUND = "vulnerability_found"
    CRITICAL_VULNERABILITY = "critical_vulnerability"
    
    # System notifications
    ACCOUNT_VERIFIED = "account_verified"
    PASSWORD_CHANGED = "password_changed"
    LOGIN_ALERT = "login_alert"
    SUSPICIOUS_ACTIVITY = "suspicious_activity"
    API_KEY_EXPIRING = "api_key_expiring"
    
    # Social notifications
    FOLLOWER_NEW = "follower_new"
    MENTION = "mention"
    REPLY = "reply"
    LIKE = "like"
    
    # Guild notifications
    GUILD_INVITE = "guild_invite"
    GUILD_JOINED = "guild_joined"
    GUILD_MESSAGE = "guild_message"
    GUILD_EVENT = "guild_event"
    
    # Marketplace notifications
    PRODUCT_PURCHASED = "product_purchased"
    PRODUCT_SOLD = "product_sold"
    LISTING_EXPIRED = "listing_expired"
    
    # System announcements
    MAINTENANCE = "maintenance"
    NEW_FEATURE = "new_feature"
    POLICY_UPDATE = "policy_update"


class NotificationChannel(str, enum.Enum):
    """Delivery channels for notifications"""
    IN_APP = "in_app"
    EMAIL = "email"
    SMS = "sms"
    PUSH = "push"
    WEBHOOK = "webhook"
    SLACK = "slack"
    DISCORD = "discord"
    TELEGRAM = "telegram"


class NotificationPriority(str, enum.Enum):
    """Notification priority levels"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"


class Notification(Base):
    """Multi-channel notification system"""
    __tablename__ = "notifications"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Recipient information
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Notification details
    type = Column(String(50), nullable=False, index=True)
    channel = Column(String(20), default=NotificationChannel.IN_APP, nullable=False)
    priority = Column(String(20), default=NotificationPriority.NORMAL, nullable=False, index=True)
    
    # Content
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    data = Column(JSON)  # additional data for frontend rendering
    
    # Routing and actions
    action_url = Column(String(500))  # deep link or URL to navigate to
    action_label = Column(String(100))  # button text like "View Bug", "Go to Dashboard"
    icon = Column(String(100))  # icon name for frontend
    
    # Related entities
    related_type = Column(String(50))  # bug, scan, payment, user, etc.
    related_id = Column(Integer)
    
    # Status tracking
    is_read = Column(Boolean, default=False, index=True)
    read_at = Column(DateTime, nullable=True)
    
    is_sent = Column(Boolean, default=False, index=True)
    sent_at = Column(DateTime, nullable=True)
    
    is_delivered = Column(Boolean, default=False)
    delivered_at = Column(DateTime, nullable=True)
    
    is_failed = Column(Boolean, default=False)
    failure_reason = Column(Text)
    retry_count = Column(Integer, default=0)
    
    # Scheduling
    scheduled_at = Column(DateTime, nullable=True)  # for delayed notifications
    expires_at = Column(DateTime, nullable=True)  # auto-delete after this time
    
    # Timing
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="notifications")
    
    # Indexes
    __table_args__ = (
        Index('idx_notification_user_read', 'user_id', 'is_read'),
        Index('idx_notification_user_created', 'user_id', 'created_at'),
        Index('idx_notification_type_created', 'type', 'created_at'),
        Index('idx_notification_scheduled', 'scheduled_at', 'is_sent'),
        Index('idx_notification_related', 'related_type', 'related_id'),
    )
    
    def __repr__(self):
        return f"<Notification(id={self.id}, user={self.user_id}, type={self.type}, read={self.is_read})>"


class NotificationPreference(Base):
    """User notification preferences"""
    __tablename__ = "notification_preferences"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, unique=True, index=True)
    
    # Channel preferences
    email_enabled = Column(Boolean, default=True)
    sms_enabled = Column(Boolean, default=False)
    push_enabled = Column(Boolean, default=True)
    webhook_enabled = Column(Boolean, default=False)
    
    # Notification type preferences (JSON to allow flexible configuration)
    type_preferences = Column(JSON, default={})  # {notification_type: {channel: bool}}
    
    # Quiet hours
    quiet_hours_enabled = Column(Boolean, default=False)
    quiet_hours_start = Column(String(5))  # "22:00"
    quiet_hours_end = Column(String(5))  # "08:00"
    quiet_hours_timezone = Column(String(50), default="UTC")
    
    # Digest settings
    digest_enabled = Column(Boolean, default=False)
    digest_frequency = Column(String(20))  # daily, weekly
    digest_time = Column(String(5))  # "09:00"
    
    # External integrations
    webhook_url = Column(String(500))
    slack_webhook = Column(String(500))
    discord_webhook = Column(String(500))
    telegram_chat_id = Column(String(100))
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="notification_preferences")
    
    def __repr__(self):
        return f"<NotificationPreference(user={self.user_id}, email={self.email_enabled}, push={self.push_enabled})>"


class NotificationTemplate(Base):
    """Notification templates for consistent messaging"""
    __tablename__ = "notification_templates"
    
    id = Column(Integer, primary_key=True)
    type = Column(String(50), unique=True, nullable=False, index=True)
    channel = Column(String(20), nullable=False)
    
    # Template content (support for placeholders)
    subject_template = Column(String(255))  # for email/push
    title_template = Column(String(255), nullable=False)
    message_template = Column(Text, nullable=False)
    
    # Template metadata
    variables = Column(JSON)  # list of available variables
    example_data = Column(JSON)  # example data for testing
    
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<NotificationTemplate(type={self.type}, channel={self.channel})>"
