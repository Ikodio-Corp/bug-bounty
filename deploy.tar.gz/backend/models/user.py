"""
User models - Authentication and user management
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, Text, Enum as SQLEnum, ForeignKey, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

from core.database import Base


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    HUNTER = "hunter"
    DEVELOPER = "developer"
    COMPANY = "company"
    UNIVERSITY = "university"
    RESEARCHER = "researcher"
    INVESTOR = "investor"


class SubscriptionTier(str, enum.Enum):
    FREE = "free"
    BRONZE = "bronze"
    SILVER = "silver"
    GOLD = "gold"
    PLATINUM = "platinum"


class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255))
    
    role = Column(SQLEnum(UserRole), default=UserRole.HUNTER, nullable=False)
    subscription_tier = Column(SQLEnum(SubscriptionTier), default=SubscriptionTier.FREE, nullable=False)
    
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    is_premium = Column(Boolean, default=False)
    email_verified = Column(Boolean, default=False)
    
    api_key = Column(String(255), unique=True, index=True)
    bio = Column(Text)
    avatar_url = Column(String(500))
    location = Column(String(255))
    website = Column(String(500))
    
    github_username = Column(String(100))
    twitter_username = Column(String(100))
    linkedin_url = Column(String(500))
    discord_username = Column(String(100))
    
    total_bounties_earned = Column(Float, default=0.0)
    total_bugs_found = Column(Integer, default=0)
    reputation_score = Column(Integer, default=0)
    hunter_rank = Column(String(50), default="bronze")
    
    specializations = Column(Text)
    skills = Column(Text)
    
    email_notifications = Column(Boolean, default=True)
    push_notifications = Column(Boolean, default=True)
    
    # OAuth/SSO fields
    oauth_provider = Column(String(50))  # google, github, microsoft, gitlab
    oauth_id = Column(String(255))
    
    # 2FA fields
    two_factor_enabled = Column(Boolean, default=False)
    two_factor_secret = Column(String(255))
    backup_codes = Column(JSON)  # List of hashed backup codes
    webauthn_credentials = Column(JSON)  # List of WebAuthn credentials
    
    # Payment fields
    stripe_customer_id = Column(String(255))
    stripe_subscription_id = Column(String(255))
    subscription_status = Column(String(50))  # active, canceled, past_due, etc.
    subscription_period_end = Column(DateTime)
    
    # Issue tracking integration fields
    jira_url = Column(String(500))
    jira_token = Column(String(500))  # Should be encrypted in production
    jira_email = Column(String(255))
    linear_token = Column(String(500))  # Should be encrypted in production
    asana_token = Column(String(500))  # Should be encrypted in production
    monday_token = Column(String(500))  # Should be encrypted in production
    
    # Bug bounty platform fields
    hackerone_username = Column(String(255))
    hackerone_token = Column(String(500))  # Should be encrypted in production
    bugcrowd_token = Column(String(500))  # Should be encrypted in production
    intigriti_token = Column(String(500))  # Should be encrypted in production
    yeswehack_token = Column(String(500))  # Should be encrypted in production
    
    # Cloud provider credentials
    aws_access_key_id = Column(String(255))
    aws_secret_access_key = Column(String(500))  # Should be encrypted in production
    aws_region = Column(String(50))
    aws_account_id = Column(String(100))
    gcp_project_id = Column(String(255))
    gcp_organization_id = Column(String(255))
    gcp_service_account_key = Column(JSON)
    azure_tenant_id = Column(String(255))
    azure_client_id = Column(String(255))
    azure_client_secret = Column(String(500))  # Should be encrypted in production
    azure_subscription_id = Column(String(255))
    
    # SAML 2.0 fields
    saml_name_id = Column(String(500))
    saml_idp = Column(String(255))
    saml_idp_configs = Column(JSON)
    saml_session_index = Column(String(500))
    
    # GDPR consent fields
    consent_marketing = Column(Boolean, default=False)
    consent_analytics = Column(Boolean, default=True)
    consent_third_party = Column(Boolean, default=False)
    consent_profiling = Column(Boolean, default=False)
    consent_automated_decision = Column(Boolean, default=True)
    consent_updated_at = Column(DateTime)
    
    # Account deletion fields
    deletion_requested_at = Column(DateTime)
    deletion_scheduled_at = Column(DateTime)
    
    last_login = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    bugs = relationship("Bug", back_populates="hunter")
    scans = relationship("Scan", back_populates="user")
    guild_memberships = relationship("GuildMembership", back_populates="user")
    subscriptions = relationship("Subscription", back_populates="user")
    
    # New relationships for added models
    audit_logs = relationship("AuditLog", foreign_keys="AuditLog.user_id", back_populates="user")
    notifications = relationship("Notification", back_populates="user")
    notification_preferences = relationship("NotificationPreference", uselist=False, back_populates="user")
    transactions_sent = relationship("Transaction", foreign_keys="Transaction.from_user_id", back_populates="from_user")
    transactions_received = relationship("Transaction", foreign_keys="Transaction.to_user_id", back_populates="to_user")
    balance = relationship("Balance", uselist=False, back_populates="user")
    payout_methods = relationship("PayoutMethod", back_populates="user")
    futures_positions = relationship("FuturesPosition", back_populates="user")
    futures_orders = relationship("FuturesOrder", back_populates="user")


class UserProfile(Base):
    __tablename__ = "user_profiles"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False, unique=True)
    
    about_me = Column(Text)
    experience_years = Column(Integer)
    
    total_scans = Column(Integer, default=0)
    successful_reports = Column(Integer, default=0)
    acceptance_rate = Column(Float, default=0.0)
    avg_severity = Column(Float, default=0.0)
    
    fastest_discovery = Column(Integer)
    longest_chain = Column(Integer)
    
    preferred_platforms = Column(Text)
    preferred_vulnerabilities = Column(Text)
    preferred_industries = Column(Text)
    
    certification_level = Column(String(50))
    certifications = Column(Text)
    education = Column(Text)
    
    ai_clone_enabled = Column(Boolean, default=False)
    ai_clone_earnings = Column(Float, default=0.0)
    
    portfolio_url = Column(String(500))
    blog_url = Column(String(500))
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Subscription(Base):
    __tablename__ = "subscriptions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    tier = Column(SQLEnum(SubscriptionTier), nullable=False)
    status = Column(String(50), default="active")
    
    stripe_subscription_id = Column(String(255))
    stripe_customer_id = Column(String(255))
    
    price = Column(Float, nullable=False)
    billing_cycle = Column(String(50))
    
    features = Column(Text)
    scans_limit = Column(Integer)
    scans_used = Column(Integer, default=0)
    
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime)
    next_billing_date = Column(DateTime)
    
    auto_renew = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", back_populates="subscriptions")
