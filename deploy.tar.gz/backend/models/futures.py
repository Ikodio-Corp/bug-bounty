"""
Futures Trading Model - Advanced trading features for security tokens and predictions
"""

from sqlalchemy import Column, Integer, String, DateTime, Float, Text, JSON, ForeignKey, Boolean, Numeric, Index
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from decimal import Decimal

from core.database import Base


class FuturesContractType(str, enum.Enum):
    """Types of futures contracts"""
    VULNERABILITY_PREDICTION = "vulnerability_prediction"
    EXPLOIT_LIKELIHOOD = "exploit_likelihood"
    SECURITY_SCORE = "security_score"
    BREACH_PROBABILITY = "breach_probability"
    BOUNTY_PAYOUT = "bounty_payout"
    PLATFORM_TOKEN = "platform_token"


class ContractStatus(str, enum.Enum):
    """Status of futures contract"""
    ACTIVE = "active"
    PENDING = "pending"
    EXPIRED = "expired"
    SETTLED = "settled"
    CANCELLED = "cancelled"


class PositionType(str, enum.Enum):
    """Trading position type"""
    LONG = "long"
    SHORT = "short"


class OrderType(str, enum.Enum):
    """Order types"""
    MARKET = "market"
    LIMIT = "limit"
    STOP_LOSS = "stop_loss"
    TAKE_PROFIT = "take_profit"


class FuturesContract(Base):
    """Futures contracts for security predictions and tokens"""
    __tablename__ = "futures_contracts"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Contract identification
    contract_id = Column(String(100), unique=True, nullable=False, index=True)
    symbol = Column(String(50), unique=True, nullable=False, index=True)  # e.g., "VUL-Q4-2024"
    
    # Contract details
    contract_type = Column(String(50), nullable=False, index=True)
    status = Column(String(20), default=ContractStatus.ACTIVE, nullable=False, index=True)
    
    # Underlying asset/prediction
    underlying_type = Column(String(50))  # vulnerability, exploit, security_score, etc.
    underlying_id = Column(Integer)
    underlying_description = Column(Text)
    
    # Contract terms
    strike_price = Column(Numeric(precision=18, scale=2))
    current_price = Column(Numeric(precision=18, scale=2), nullable=False)
    opening_price = Column(Numeric(precision=18, scale=2), nullable=False)
    
    # Price limits
    price_floor = Column(Numeric(precision=18, scale=2))
    price_ceiling = Column(Numeric(precision=18, scale=2))
    
    # Contract size and leverage
    contract_size = Column(Integer, default=1)  # multiplier
    max_leverage = Column(Float, default=1.0)  # 1x to 100x
    
    # Expiry
    expires_at = Column(DateTime, nullable=False, index=True)
    settlement_date = Column(DateTime)
    settlement_price = Column(Numeric(precision=18, scale=2))
    
    # Trading statistics
    total_volume = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    open_interest = Column(Integer, default=0)  # total open positions
    daily_volume = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    
    # Price history (24h)
    high_24h = Column(Numeric(precision=18, scale=2))
    low_24h = Column(Numeric(precision=18, scale=2))
    change_24h = Column(Float, default=0.0)
    
    # Market data
    bid_price = Column(Numeric(precision=18, scale=2))
    ask_price = Column(Numeric(precision=18, scale=2))
    last_trade_price = Column(Numeric(precision=18, scale=2))
    last_trade_at = Column(DateTime)
    
    # Contract metadata
    description = Column(Text)
    terms = Column(JSON)
    settlement_rules = Column(JSON)
    
    # Risk parameters
    margin_requirement = Column(Float, default=0.1)  # 10% margin
    liquidation_threshold = Column(Float, default=0.05)  # 5% from margin call
    
    # Timing
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    positions = relationship("FuturesPosition", back_populates="contract")
    orders = relationship("FuturesOrder", back_populates="contract")
    
    # Indexes
    __table_args__ = (
        Index('idx_contract_type_status', 'contract_type', 'status'),
        Index('idx_contract_expires', 'expires_at', 'status'),
    )
    
    def __repr__(self):
        return f"<FuturesContract(symbol={self.symbol}, type={self.contract_type}, price={self.current_price})>"


class FuturesPosition(Base):
    """User positions in futures contracts"""
    __tablename__ = "futures_positions"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Position identification
    position_id = Column(String(100), unique=True, nullable=False, index=True)
    
    # Ownership
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    contract_id = Column(Integer, ForeignKey("futures_contracts.id"), nullable=False, index=True)
    
    # Position details
    position_type = Column(String(10), nullable=False)  # long or short
    quantity = Column(Integer, nullable=False)
    entry_price = Column(Numeric(precision=18, scale=2), nullable=False)
    current_price = Column(Numeric(precision=18, scale=2), nullable=False)
    
    # Leverage and margin
    leverage = Column(Float, default=1.0, nullable=False)
    margin = Column(Numeric(precision=18, scale=2), nullable=False)
    margin_used = Column(Numeric(precision=18, scale=2), nullable=False)
    
    # P&L tracking
    unrealized_pnl = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    realized_pnl = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    total_pnl = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    roi_percentage = Column(Float, default=0.0)
    
    # Risk management
    stop_loss = Column(Numeric(precision=18, scale=2))
    take_profit = Column(Numeric(precision=18, scale=2))
    liquidation_price = Column(Numeric(precision=18, scale=2))
    
    is_liquidated = Column(Boolean, default=False)
    liquidated_at = Column(DateTime)
    
    # Status
    is_open = Column(Boolean, default=True, index=True)
    is_closed = Column(Boolean, default=False)
    
    # Timing
    opened_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    closed_at = Column(DateTime)
    
    # Fees
    opening_fee = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    closing_fee = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    funding_fee = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    
    # Metadata
    notes = Column(Text)
    position_metadata = Column(JSON)  # renamed from metadata
    
    # Relationships
    user = relationship("User", back_populates="futures_positions")
    contract = relationship("FuturesContract", back_populates="positions")
    
    # Indexes
    __table_args__ = (
        Index('idx_position_user_status', 'user_id', 'is_open'),
        Index('idx_position_contract_status', 'contract_id', 'is_open'),
    )
    
    def __repr__(self):
        return f"<FuturesPosition(id={self.position_id}, user={self.user_id}, type={self.position_type}, pnl={self.total_pnl})>"


class FuturesOrder(Base):
    """Orders for futures trading"""
    __tablename__ = "futures_orders"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Order identification
    order_id = Column(String(100), unique=True, nullable=False, index=True)
    
    # Ownership
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    contract_id = Column(Integer, ForeignKey("futures_contracts.id"), nullable=False, index=True)
    position_id = Column(Integer, ForeignKey("futures_positions.id"), nullable=True)
    
    # Order details
    order_type = Column(String(20), nullable=False)  # market, limit, stop_loss, take_profit
    side = Column(String(10), nullable=False)  # buy or sell
    position_type = Column(String(10), nullable=False)  # long or short
    
    # Quantity and price
    quantity = Column(Integer, nullable=False)
    filled_quantity = Column(Integer, default=0)
    remaining_quantity = Column(Integer)
    
    price = Column(Numeric(precision=18, scale=2))  # for limit orders
    trigger_price = Column(Numeric(precision=18, scale=2))  # for stop orders
    average_fill_price = Column(Numeric(precision=18, scale=2))
    
    # Leverage
    leverage = Column(Float, default=1.0)
    
    # Status
    status = Column(String(20), default="pending", nullable=False, index=True)  # pending, partial, filled, cancelled, expired
    
    # Timing
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    filled_at = Column(DateTime)
    expires_at = Column(DateTime)  # for GTD orders
    
    # Fees
    fee = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    fee_currency = Column(String(10), default="USD")
    
    # Execution details
    execution_details = Column(JSON)  # fills, partial fills, etc.
    
    # Relationships
    user = relationship("User", back_populates="futures_orders")
    contract = relationship("FuturesContract", back_populates="orders")
    position = relationship("FuturesPosition")
    
    # Indexes
    __table_args__ = (
        Index('idx_order_user_status', 'user_id', 'status'),
        Index('idx_order_contract_status', 'contract_id', 'status'),
    )
    
    def __repr__(self):
        return f"<FuturesOrder(id={self.order_id}, user={self.user_id}, type={self.order_type}, status={self.status})>"


class FuturesPredictionMarket(Base):
    """Prediction market for security events"""
    __tablename__ = "futures_prediction_markets"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Market identification
    market_id = Column(String(100), unique=True, nullable=False, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    
    # Market type
    category = Column(String(50), index=True)  # vulnerability, breach, exploit, etc.
    
    # Prediction question
    question = Column(Text, nullable=False)
    possible_outcomes = Column(JSON, nullable=False)  # list of possible outcomes
    
    # Current odds/probabilities
    outcome_probabilities = Column(JSON)  # {outcome: probability}
    
    # Market status
    status = Column(String(20), default="active", index=True)
    
    # Resolution
    resolved_outcome = Column(String(100))
    resolved_at = Column(DateTime)
    resolution_source = Column(Text)
    
    # Trading statistics
    total_volume = Column(Numeric(precision=18, scale=2), default=Decimal('0'))
    total_traders = Column(Integer, default=0)
    
    # Timing
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    closes_at = Column(DateTime, nullable=False, index=True)
    
    # Metadata
    market_metadata = Column(JSON)  # renamed from metadata
    
    def __repr__(self):
        return f"<FuturesPredictionMarket(id={self.market_id}, title={self.title}, status={self.status})>"
