from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, ARRAY
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
from core.database import Base


class Certificate(Base):
    """Certificate model for user achievements and certifications"""
    
    __tablename__ = "certificates"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(255), nullable=False)
    issuer = Column(String(255), nullable=False)
    type = Column(String(50), nullable=False)  # course, achievement, certification
    issued_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)
    credential_id = Column(String(255), nullable=False, unique=True, index=True)
    skills = Column(ARRAY(String), nullable=True)
    verified = Column(Boolean, default=True)
    description = Column(Text, nullable=True)
    cert_metadata = Column(JSONB, nullable=True)  # renamed from metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="certificates")
    
    def __repr__(self):
        return f"<Certificate {self.name} - {self.credential_id}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "name": self.name,
            "issuer": self.issuer,
            "type": self.type,
            "issued_at": self.issued_at.isoformat() if self.issued_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "credential_id": self.credential_id,
            "skills": self.skills,
            "verified": self.verified,
            "description": self.description,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }
