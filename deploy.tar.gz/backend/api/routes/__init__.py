"""
API routes package
"""

# All routes are imported in main.py
