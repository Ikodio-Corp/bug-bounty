import AdvancedAnalyticsDashboard from '@/components/AdvancedAnalyticsDashboard';

export default function AnalyticsPage() {
  return <AdvancedAnalyticsDashboard />;
}
