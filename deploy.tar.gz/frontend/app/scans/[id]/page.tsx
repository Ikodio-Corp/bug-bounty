"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { api } from "@/lib/api";

interface Vulnerability {
  id: number;
  title: string;
  severity: string;
  cve_id?: string;
  description: string;
  recommendation: string;
  affected_component: string;
}

interface ScanDetail {
  id: number;
  target_url: string;
  scan_type: string;
  status: string;
  progress: number;
  vulnerabilities_found: number;
  started_at: string;
  completed_at?: string;
  vulnerabilities: Vulnerability[];
}

export default function ScanDetailPage() {
  const params = useParams();
  const router = useRouter();
  const [scan, setScan] = useState<ScanDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedSeverity, setSelectedSeverity] = useState<string>("all");

  useEffect(() => {
    fetchScanDetail();
    const interval = setInterval(fetchScanDetail, 3000);
    return () => clearInterval(interval);
  }, [params.id]);

  const fetchScanDetail = async () => {
    try {
      const response = await api.get(`/scans/${params.id}`);
      setScan(response.data);
    } catch (error) {
      console.error("Failed to fetch scan details:", error);
    } finally {
      setLoading(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case "critical":
        return "text-red-400 bg-red-500/10 border-red-500/50";
      case "high":
        return "text-orange-400 bg-orange-500/10 border-orange-500/50";
      case "medium":
        return "text-yellow-400 bg-yellow-500/10 border-yellow-500/50";
      case "low":
        return "text-blue-400 bg-blue-500/10 border-blue-500/50";
      default:
        return "text-slate-400 bg-slate-500/10 border-slate-500/50";
    }
  };

  const filteredVulnerabilities = scan?.vulnerabilities.filter(
    v => selectedSeverity === "all" || v.severity.toLowerCase() === selectedSeverity
  ) || [];

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-cyan-500 border-t-transparent"></div>
          <p className="text-slate-400 mt-4">Loading scan details...</p>
        </div>
      </div>
    );
  }

  if (!scan) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-400 text-lg">Scan not found</p>
          <button
            onClick={() => router.push("/scans")}
            className="mt-4 px-6 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition"
          >
            Back to Scans
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <div className="lg:ml-64">
        <div className="p-8">
          <button
            onClick={() => router.push("/scans")}
            className="flex items-center text-slate-400 hover:text-white mb-6 transition"
          >
            <svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Scans
          </button>

          <div className="bg-slate-900/50 backdrop-blur border border-slate-800 rounded-lg p-6 mb-8">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-2xl font-bold text-white mb-2">{scan.target_url}</h1>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    scan.status === "completed" ? "text-green-400 bg-green-500/10" :
                    scan.status === "running" ? "text-blue-400 bg-blue-500/10" :
                    scan.status === "failed" ? "text-red-400 bg-red-500/10" :
                    "text-yellow-400 bg-yellow-500/10"
                  }`}>
                    {scan.status.toUpperCase()}
                  </span>
                  <span className="text-slate-400">{scan.scan_type} scan</span>
                </div>
              </div>
              <button className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition">
                Export Report
              </button>
            </div>

            {scan.status === "running" && (
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-400">Scan Progress</span>
                  <span className="text-sm text-slate-300">{scan.progress}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-300"
                    style={{ width: `${scan.progress}%` }}
                  ></div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              <div>
                <p className="text-sm text-slate-400 mb-1">Started</p>
                <p className="text-white font-semibold">{new Date(scan.started_at).toLocaleString()}</p>
              </div>
              {scan.completed_at && (
                <div>
                  <p className="text-sm text-slate-400 mb-1">Completed</p>
                  <p className="text-white font-semibold">{new Date(scan.completed_at).toLocaleString()}</p>
                </div>
              )}
              <div>
                <p className="text-sm text-slate-400 mb-1">Total Vulnerabilities</p>
                <p className="text-2xl font-bold text-red-400">{scan.vulnerabilities_found}</p>
              </div>
              <div>
                <p className="text-sm text-slate-400 mb-1">Scan ID</p>
                <p className="text-white font-mono">#{scan.id}</p>
              </div>
            </div>
          </div>

          <div className="mb-6 flex items-center space-x-3">
            <span className="text-slate-400">Filter by severity:</span>
            {["all", "critical", "high", "medium", "low"].map((severity) => (
              <button
                key={severity}
                onClick={() => setSelectedSeverity(severity)}
                className={`px-4 py-2 rounded-lg font-semibold transition ${
                  selectedSeverity === severity
                    ? "bg-cyan-600 text-white"
                    : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                }`}
              >
                {severity.charAt(0).toUpperCase() + severity.slice(1)}
              </button>
            ))}
          </div>

          {filteredVulnerabilities.length === 0 ? (
            <div className="bg-slate-900/50 backdrop-blur border border-slate-800 rounded-lg p-12 text-center">
              <p className="text-slate-400 text-lg">No vulnerabilities found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredVulnerabilities.map((vuln) => (
                <div
                  key={vuln.id}
                  className="bg-slate-900/50 backdrop-blur border border-slate-800 rounded-lg p-6 hover:border-slate-700 transition"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className={`px-3 py-1 rounded-lg text-xs font-semibold border ${getSeverityColor(vuln.severity)}`}>
                          {vuln.severity.toUpperCase()}
                        </span>
                        {vuln.cve_id && (
                          <span className="px-3 py-1 bg-slate-800 text-slate-300 rounded-lg text-xs font-mono">
                            {vuln.cve_id}
                          </span>
                        )}
                      </div>
                      <h3 className="text-xl font-semibold text-white mb-2">{vuln.title}</h3>
                      <p className="text-sm text-slate-400 mb-1">
                        <span className="font-semibold">Component:</span> {vuln.affected_component}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-semibold text-slate-300 mb-2">Description</h4>
                      <p className="text-slate-400">{vuln.description}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-slate-300 mb-2">Recommendation</h4>
                      <p className="text-slate-400">{vuln.recommendation}</p>
                    </div>
                  </div>

                  <div className="mt-4 flex space-x-3">
                    <button className="px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-500 transition text-sm font-semibold">
                      Create Bug Report
                    </button>
                    <button className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition text-sm">
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
