"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";

interface Scan {
  id: number;
  target_url: string;
  scan_type: string;
  status: string;
  progress: number;
  vulnerabilities_found: number;
  started_at: string;
  completed_at?: string;
}

export default function ScansPage() {
  const router = useRouter();
  const [scans, setScans] = useState<Scan[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewScanModal, setShowNewScanModal] = useState(false);

  useEffect(() => {
    fetchScans();
    const interval = setInterval(fetchScans, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchScans = async () => {
    try {
      const response = await api.get("/scans");
      setScans(response.data);
    } catch (error) {
      console.error("Failed to fetch scans:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Security Scans</h1>
        <Link
          href="/scans/new"
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
        >
          New Scan
        </Link>
      </div>

      <div className="mb-8 bg-green-50 border border-green-200 rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-2">90-Second Discovery</h2>
        <p className="text-gray-700">
          Run AI-powered security scans that complete in 90 seconds. Discover
          vulnerabilities using advanced scanners and machine learning.
        </p>
      </div>

      {scans.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No scans yet</p>
          <Link
            href="/scans/new"
            className="inline-block mt-4 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
          >
            Start Your First Scan
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {scans.map((scan) => (
            <Link
              key={scan.id}
              href={`/scans/${scan.id}`}
              className="block bg-white rounded-lg shadow hover:shadow-lg transition p-6"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span
                      className={`px-3 py-1 rounded text-sm ${
                        scan.status === "completed"
                          ? "bg-green-100 text-green-800"
                          : scan.status === "running"
                          ? "bg-blue-100 text-blue-800"
                          : scan.status === "failed"
                          ? "bg-red-100 text-red-800"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {scan.status}
                    </span>
                    {scan.status === "running" && (
                      <span className="text-sm text-gray-500">In progress...</span>
                    )}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{scan.target_url}</h3>
                  <p className="text-gray-600">
                    Duration: {scan.duration_seconds || 0}s
                  </p>
                </div>
                <div className="ml-4 text-right">
                  <p className="text-2xl font-bold text-red-600">
                    {scan.vulnerabilities_found}
                  </p>
                  <p className="text-sm text-gray-500">Vulnerabilities</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
