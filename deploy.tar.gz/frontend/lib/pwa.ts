'use client';

import { useEffect } from 'react';

export function PWAInstaller() {
  useEffect(() => {
    // Register service worker
    if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
      window.addEventListener('load', () => {
        navigator.serviceWorker
          .register('/service-worker.js')
          .then((registration) => {
            console.log('Service Worker registered:', registration);
            
            // Check for updates periodically
            setInterval(() => {
              registration.update();
            }, 60000); // Check every minute
            
            // Handle updates
            registration.addEventListener('updatefound', () => {
              const newWorker = registration.installing;
              
              if (newWorker) {
                newWorker.addEventListener('statechange', () => {
                  if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                    // New service worker available
                    if (confirm('New version available! Reload to update?')) {
                      newWorker.postMessage({ type: 'SKIP_WAITING' });
                      window.location.reload();
                    }
                  }
                });
              }
            });
          })
          .catch((error) => {
            console.error('Service Worker registration failed:', error);
          });
      });
      
      // Handle controller change
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        window.location.reload();
      });
    }
    
    // Install prompt handler
    let deferredPrompt: any;
    
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      
      // Show custom install button/banner
      showInstallPromotion();
    });
    
    window.addEventListener('appinstalled', () => {
      console.log('PWA installed');
      deferredPrompt = null;
      hideInstallPromotion();
    });
    
    function showInstallPromotion() {
      const installButton = document.getElementById('pwa-install-button');
      if (installButton) {
        installButton.style.display = 'block';
        installButton.onclick = async () => {
          if (deferredPrompt) {
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            console.log('Install prompt outcome:', outcome);
            deferredPrompt = null;
            hideInstallPromotion();
          }
        };
      }
    }
    
    function hideInstallPromotion() {
      const installButton = document.getElementById('pwa-install-button');
      if (installButton) {
        installButton.style.display = 'none';
      }
    }
    
    // Push notifications
    if ('Notification' in window && 'PushManager' in window) {
      // Request permission on user interaction
      document.addEventListener('click', requestNotificationPermission, { once: true });
    }
    
    async function requestNotificationPermission() {
      if (Notification.permission === 'default') {
        const permission = await Notification.requestPermission();
        
        if (permission === 'granted') {
          subscribeToPush();
        }
      }
    }
    
    async function subscribeToPush() {
      try {
        const registration = await navigator.serviceWorker.ready;
        
        const subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY
        });
        
        // Send subscription to backend
        await fetch('/api/push/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(subscription)
        });
        
        console.log('Push subscription successful');
      } catch (error) {
        console.error('Push subscription failed:', error);
      }
    }
    
    // Periodic background sync
    navigator.serviceWorker.ready.then(async (registration) => {
      if ('periodicSync' in registration) {
        try {
          await (registration as any).periodicSync.register('update-bugs', {
            minInterval: 24 * 60 * 60 * 1000 // Once per day
          });
          
          await (registration as any).periodicSync.register('update-scans', {
            minInterval: 24 * 60 * 60 * 1000
          });
        } catch (error) {
          console.error('Periodic sync registration failed:', error);
        }
      }
    });
    
    // Handle online/offline status
    window.addEventListener('online', () => {
      console.log('Back online');
      // Trigger background sync
      navigator.serviceWorker.ready.then((registration) => {
        if ('sync' in registration) {
          (registration as any).sync.register('sync-bugs');
          (registration as any).sync.register('sync-scans');
        }
      });
    });
    
    window.addEventListener('offline', () => {
      console.log('Offline mode');
    });
  }, []);
  
  return null;
}

export function isStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true
  );
}

export function isPWAInstalled(): boolean {
  return isStandalone();
}

export function canInstallPWA(): boolean {
  if (typeof window === 'undefined') return false;
  
  return 'BeforeInstallPromptEvent' in window;
}
