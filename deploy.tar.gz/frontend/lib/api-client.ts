/**
 * Centralized API client for IKODIO Bug Bounty Platform
 * Handles authentication, error handling, and request/response formatting
 */

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1'

export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export class ApiError extends Error {
  constructor(
    public statusCode: number,
    public message: string,
    public data?: any
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

/**
 * Get authentication token from localStorage
 */
const getAuthToken = (): string | null => {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('token')
  }
  return null
}

/**
 * Set authentication token to localStorage
 */
export const setAuthToken = (token: string): void => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('token', token)
  }
}

/**
 * Remove authentication token from localStorage
 */
export const removeAuthToken = (): void => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('token')
  }
}

/**
 * Make authenticated API request
 */
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  const token = getAuthToken()
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  }

  if (options.headers) {
    Object.assign(headers, options.headers)
  }

  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  const url = `${API_BASE_URL}${endpoint}`

  try {
    const response = await fetch(url, {
      ...options,
      headers,
    })

    const data = await response.json()

    if (!response.ok) {
      throw new ApiError(
        response.status,
        data.message || data.error || 'Request failed',
        data
      )
    }

    return data
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    
    throw new ApiError(
      500,
      error instanceof Error ? error.message : 'Network error',
      error
    )
  }
}

// ============================================
// AUTHENTICATION
// ============================================

export const authApi = {
  login: (email: string, password: string) =>
    apiRequest<{ access_token: string; token_type: string; user: any }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  register: (email: string, password: string, username: string) =>
    apiRequest<{ user: any }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, username }),
    }),

  logout: () => removeAuthToken(),

  getCurrentUser: () => apiRequest<any>('/auth/me'),
}

// ============================================
// BUG MANAGEMENT
// ============================================

export const bugApi = {
  list: (params?: { status?: string; severity?: string; page?: number }) =>
    apiRequest<any>(`/bugs?${new URLSearchParams(params as any)}`),

  get: (bugId: number) => apiRequest<any>(`/bugs/${bugId}`),

  create: (data: any) =>
    apiRequest<any>('/bugs', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  update: (bugId: number, data: any) =>
    apiRequest<any>(`/bugs/${bugId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  delete: (bugId: number) =>
    apiRequest<any>(`/bugs/${bugId}`, {
      method: 'DELETE',
    }),
}

// ============================================
// INSURANCE
// ============================================

export const insuranceApi = {
  calculatePremium: (coverageAmount: number, companySize: string, industryRisk: string) =>
    apiRequest<any>('/insurance/calculate-premium', {
      method: 'POST',
      body: JSON.stringify({ coverage_amount: coverageAmount, company_size: companySize, industry_risk: industryRisk }),
    }),

  createPolicy: (data: any) =>
    apiRequest<any>('/insurance/policies', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  listPolicies: () => apiRequest<any>('/insurance/policies'),

  submitClaim: (policyId: number, data: any) =>
    apiRequest<any>(`/insurance/claims`, {
      method: 'POST',
      body: JSON.stringify({ policy_id: policyId, ...data }),
    }),
}

// ============================================
// SECURITY SCORE
// ============================================

export const securityScoreApi = {
  calculate: (companyId: number) =>
    apiRequest<any>(`/security-score/calculate/${companyId}`, {
      method: 'POST',
    }),

  get: (companyId: number) => apiRequest<any>(`/security-score/${companyId}`),

  getHistory: (companyId: number) =>
    apiRequest<any>(`/security-score/${companyId}/history`),

  getReport: (companyId: number) =>
    apiRequest<any>(`/security-score/${companyId}/report`),

  getComponentBreakdown: (companyId: number) =>
    apiRequest<any>(`/security-score/${companyId}/components`),
}

// ============================================
// MARKETPLACE
// ============================================

export const marketplaceApi = {
  listBugs: (params?: { severity?: string; price_min?: number; price_max?: number }) =>
    apiRequest<any>(`/marketplace/bugs?${new URLSearchParams(params as any)}`),

  buyBug: (bugId: number) =>
    apiRequest<any>(`/marketplace/bugs/${bugId}/buy`, {
      method: 'POST',
    }),

  listFutures: () => apiRequest<any>('/marketplace/futures'),

  createFuture: (data: any) =>
    apiRequest<any>('/marketplace/futures', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  buyFuturePosition: (futureId: number, positionType: 'long' | 'short', contracts: number) =>
    apiRequest<any>(`/marketplace/futures/${futureId}/position`, {
      method: 'POST',
      body: JSON.stringify({ position_type: positionType, contracts }),
    }),

  settleFuturePosition: (positionId: number) =>
    apiRequest<any>(`/marketplace/futures/positions/${positionId}/settle`, {
      method: 'POST',
    }),
}

// ============================================
// DAO GOVERNANCE
// ============================================

export const daoApi = {
  getBalance: (userId: number) => apiRequest<any>(`/dao/balance/${userId}`),

  createProposal: (data: any) =>
    apiRequest<any>('/dao/proposals', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  listProposals: (status?: string) =>
    apiRequest<any>(`/dao/proposals${status ? `?status=${status}` : ''}`),

  getProposal: (proposalId: number) => apiRequest<any>(`/dao/proposals/${proposalId}`),

  vote: (proposalId: number, voteType: 'for' | 'against' | 'abstain') =>
    apiRequest<any>(`/dao/proposals/${proposalId}/vote`, {
      method: 'POST',
      body: JSON.stringify({ vote_type: voteType }),
    }),

  finalizeProposal: (proposalId: number) =>
    apiRequest<any>(`/dao/proposals/${proposalId}/finalize`, {
      method: 'POST',
    }),

  stakeTokens: (userId: number, amount: number, durationDays: number) =>
    apiRequest<any>('/dao/stake', {
      method: 'POST',
      body: JSON.stringify({ user_id: userId, amount, duration_days: durationDays }),
    }),

  unstakeTokens: (stakeId: number) =>
    apiRequest<any>(`/dao/stake/${stakeId}/unstake`, {
      method: 'POST',
    }),
}

// ============================================
// DEVOPS AUTOPILOT
// ============================================

export const devopsApi = {
  listResources: () => apiRequest<any>('/devops/resources'),

  provisionResource: (data: any) =>
    apiRequest<any>('/devops/provision', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  listJobs: () => apiRequest<any>('/devops/jobs'),

  deployApplication: (data: any) =>
    apiRequest<any>('/devops/deploy', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  listHealingEvents: () => apiRequest<any>('/devops/self-healing/events'),

  optimizeCosts: () =>
    apiRequest<any>('/devops/optimize-costs', {
      method: 'POST',
    }),

  autoScale: (resourceId: number, data: any) =>
    apiRequest<any>(`/devops/resources/${resourceId}/auto-scale`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
}

// ============================================
// SCANS
// ============================================

export const scanApi = {
  list: () => apiRequest<any>('/scans'),

  get: (scanId: number) => apiRequest<any>(`/scans/${scanId}`),

  create: (data: any) =>
    apiRequest<any>('/scans', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getResults: (scanId: number) => apiRequest<any>(`/scans/${scanId}/results`),
}

// ============================================
// AUTO FIX (90-SECOND BUG FIX)
// ============================================

export const autoFixApi = {
  analyze: (bugId: number) =>
    apiRequest<any>(`/auto-fix/${bugId}/analyze`, {
      method: 'POST',
    }),

  generateFix: (bugId: number) =>
    apiRequest<any>(`/auto-fix/${bugId}/generate`, {
      method: 'POST',
    }),

  apply: (bugId: number, fixId: number, options?: any) =>
    apiRequest<any>(`/auto-fix/${bugId}/apply/${fixId}`, {
      method: 'POST',
      body: JSON.stringify(options || {}),
    }),

  getStatus: (bugId: number) => apiRequest<any>(`/auto-fix/${bugId}/status`),
}

// ============================================
// WEBHOOKS
// ============================================

export const webhookApi = {
  list: () => apiRequest<any>('/webhooks'),

  create: (data: any) =>
    apiRequest<any>('/webhooks', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  delete: (webhookId: number) =>
    apiRequest<any>(`/webhooks/${webhookId}`, {
      method: 'DELETE',
    }),

  test: (webhookId: number) =>
    apiRequest<any>(`/webhooks/${webhookId}/test`, {
      method: 'POST',
    }),
}

// Export all APIs
const apiClient = {
  auth: authApi,
  bugs: bugApi,
  insurance: insuranceApi,
  securityScore: securityScoreApi,
  marketplace: marketplaceApi,
  dao: daoApi,
  devops: devopsApi,
  scans: scanApi,
  autoFix: autoFixApi,
  webhooks: webhookApi,
}

export default apiClient
export { apiClient }
