import axios from 'axios'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true

      try {
        const refreshToken = localStorage.getItem('refresh_token')
        const response = await axios.post(`${API_URL}/api/auth/refresh`, {
          refresh_token: refreshToken,
        })

        const { access_token, refresh_token } = response.data
        localStorage.setItem('access_token', access_token)
        localStorage.setItem('refresh_token', refresh_token)

        originalRequest.headers.Authorization = `Bearer ${access_token}`
        return api(originalRequest)
      } catch (refreshError) {
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        window.location.href = '/login'
        return Promise.reject(refreshError)
      }
    }

    return Promise.reject(error)
  }
)

// Auth API
export const authAPI = {
  register: (data: any) => api.post('/auth/register', data),
  login: (data: any) => api.post('/auth/login', data),
  logout: () => api.post('/auth/logout'),
  me: () => api.get('/users/me'),
}

// Bugs API
export const bugsAPI = {
  list: (params?: any) => api.get('/bugs', { params }),
  get: (id: number) => api.get(`/bugs/${id}`),
  create: (data: any) => api.post('/bugs', data),
  update: (id: number, data: any) => api.put(`/bugs/${id}`, data),
  delete: (id: number) => api.delete(`/bugs/${id}`),
}

// Scans API
export const scansAPI = {
  start: (data: any) => api.post('/scans/start', data),
  get: (id: number) => api.get(`/scans/${id}`),
  results: (id: number) => api.get(`/scans/${id}/results`),
  list: (params?: any) => api.get('/scans', { params }),
}

// Marketplace API
export const marketplaceAPI = {
  listings: (params?: any) => api.get('/marketplace/listings', { params }),
  create: (data: any) => api.post('/marketplace/list', data),
  buy: (id: number) => api.post(`/marketplace/buy/${id}`),
}

// Intelligence API
export const intelligenceAPI = {
  scores: (company: string) => api.get(`/intelligence/scores/${company}`),
  reports: (params?: any) => api.get('/intelligence/reports', { params }),
  generate: (data: any) => api.post('/intelligence/reports/generate', data),
}

// Guild API
export const guildAPI = {
  list: () => api.get('/guild'),
  join: (id: number) => api.post(`/guild/join/${id}`),
  proposals: (guildId: number) => api.get(`/guild/${guildId}/proposals`),
  createProposal: (guildId: number, data: any) => api.post(`/guild/${guildId}/proposals`, data),
}

export default api
